# Events Calendar for Aberdeen University events
A python web application for presenting and recommending various events from Aberdeen University using [Django](https://www.djangoproject.com/ "The Django Project Homepage").

## Installing
Before use, create a file `settings.py` in the `src` directory and override values from `settings_base.py` in there. You should change at least `SECRET_KEY` and potetially `DEBUG` before running the application.
Since the server uses Python 3, this will be required before running it.

The required PIP packages may be installed by running `pip install -r requirements.txt`.

## Developing
Run the command 'scrapyd' from within the 'src' folder.
The Django test server can be run with the command `python manage.py runserver` from within the `src` folder with another command line window.

## Production
In production, a WSGI server should be directed to use the wsgi.py file to run the server. Settings should be changed accordingly in the created settings.py file.
