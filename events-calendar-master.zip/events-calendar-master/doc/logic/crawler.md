# Crawler Interface
### crawl()<a id="crawl"></a>
This function can be called to start a blocking crawl that will halt the thread until completion. Notably, it must be called from the main thread.