# Dispatcher Interface
### on( class [DispatcherEvent](../objects/DispatcherEvent.md#DispatcherEvent) eventClass,  Callable callback )<a id="on"></a>
This function is used to listen for events.
When an event of the specified type is recieved, the callback will be called with the event instance as the first parameter.
In the case that there are several sources listening to the same type of event, they will recieve the event in the order they registered their interest.
### when( * [DispatcherEvent](../objects/DispatcherEvent.md#DispatcherEvent) events)<a id="when"></a>
A decorator function which is equivilent to calling `on(function, event)` for each event in events.
### dispatch( [DispatcherEvent](../objects/DispatcherEvent.md#DispatcherEvent) event )<a id="dispatch"></a>
This function is used to signal that an event has occured.
All callbacks registered with the same type as the event parameter will be called in the order that they were registered.
