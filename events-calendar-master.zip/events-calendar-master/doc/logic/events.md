# Events Interface
### getPopularEvents()
Returns a list of popular events
### getEvents( [User](../objects/User.md#User) user=None )<a id="getEvents"></a>
This function can be called upon to obtain a list of all events available to the given user.
If no user is given, the events will contain only publicly available events.

It returns an array of events in no particular order if the user is valid or `None` and raises an error otherwise.
### getEventRuns()
returns a list of all event runs
### getEvent( id )
Returns an event by id
### filterEvents( list [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) events, dict filters )
Returns a subset of `events` which pass the given filters
### getCategories()
Returns a list of all events in the system
### compareVenues( [Venue](../objects/CalendarEvent.md#Venue) a, [Venue](../objects/CalendarEvent.md#Venue) b, )
Compare two events and return `True` if they are the same
### createEvent( [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) event )
Attempts to store the given event in the system
### editEvent( [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) old, [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) new )
Attempts to save the old event with the new events
### updateEvent( [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) event )
Flushes changes made to an event and it's base
### searchForEvent( str term )
Returns a list of all events matching a given search term
### validateEvent( dict data )
Attempts to parse data as an event and returns that event
### deleteEvent
Deletes and event from the system
### asyncCrawl
Will issue commands to the crawler to crawl for new events