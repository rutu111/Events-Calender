# Integrations Interface
### FACEBOOK<a id="FACEBOOK"></a>
A constant variable whch points to the singleton for the integration of this type.
