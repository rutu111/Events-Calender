# Recommendations
### generateRecommendations( bool override=False, bool adminTest=False )
Generates recommendation objects with weightings given by the SVD algorithm and dispatches them
### getRecommendedEvents( [User](../objects/User.md#User) user )<a id="getRecommendedEvents"></a>
This function can be called upon to obtain a list of events recommended to the given user.

It returns an array of recommended events in no particular order if the user is valid and raises an error otherwise.
### generateRecommendationsAsync( _ )
Calls generateRecommendations in a split thread
### processCategoryWeightingsForAllUsers()
Generates weighting values based on user feedback
### processFeedback( [UserFeedbackEvent](../objects/DispatcherEvent.md#UserFeedbackEvent) feedbackEvent )
Stores and processes the feedback indicated by the event
### processRecommendation( [DiscoveredRecommendationEvent](../objects/DispatcherEvent.md#DiscoveredRecommendationEvent) recommendationEvent )
Stores and processes the recommendation indicated by the event
### getFeedbackForUser( [User](../objects/User.md#User) user )
Returns a list of feedback associated with the given user
### getPositiveEvents( [User](../objects/User.md#User) user )
Returns a list of events with positive feedback for a given user
### getNegativeEvents( [User](../objects/User.md#User) user )
Returns a list of events with negative feedback for a given user
### getFeedbackForEvent( [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) event )
Returns a list of feedback associated with the given event
### getPositiveFeedbackCount( [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) event )
Returns a list of events with positive feedback for a given event
### getNegativeFeedbackCount( [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) event )
Returns a list of events with negative feedback for a given event
