# User Interface
### getUser( id )<a id="getUser"></a>
This function can be called upon to obtain a user with a given ID.

It will return the User object representing this user or `None` if no such user exists.
### getAllUsers(  )
Returns a list of all users in the system
### authenticate( code, [Integration](../objects/Integrration.md#Integration) integration=[FACEBOOK](integrations#FACEBOOK) )
Attempts to log the user into the given integration with the provided oauth code
### getLoginURL( dict scope=None, [Integration](../objects/Integrration.md#Integration) integration=[FACEBOOK](integrations#FACEBOOK) )
Generate the required login url for the integration
### doFeedback( [User](../objects/User.md#User) user, [CalendarEventRun](../objects/CalendarEvent.md#CalendarEventRun) event, float rating )
Stores a feedback object representing `rating` on `event` by `user`
### addOrUpdateUser( [UserLoginEvent](../objects/DispatcherEvent.md#UserLoginEvent) loginEvent )
Either adds a new user or fetches an old one and updates it when someone logs it.
### adminLogin( str username, str password )
Returns a boolean value indicating if the provided details are valid admin credentials.
### setInterests( [User](../objects/User.md#User) user, dict interests)
Updates a users category preferences according to `interests`