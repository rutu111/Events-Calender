### CalendarEvent( String title, String url=None, String description=None, String content=None, String thumbnail=None, String preview=None )<a id="CalendarEvent"></a>
The `CalendarEvent` class reprents any event in the system.
Events should be created internally but are exposed so that type-checking can be done.
### CalendarEventRun( referenceID, [CalendarEvent](#CalendarEvent) base, datetime start, datetime end, [Venue](#Venue) venue)<a id="CalendarEventRun"></a>
CalendarEventRun represent an event that actually happens. This system allows for repeating events to use the same `CalendarEvent` base object.
### Venue( address, latitude=None, longitude=None, String url=None, String description=None)<a id="Venue"></a>
A location at which an event is hosted