### DispatcherEvent(  )<a id="DispatcherEvent"></a>
The `DispatcherEvent` class is abstract and instances implementing it represent an internal system event.
### CrawlerDiscoveredCalendarEventEvent( [CalendarEventRun](CalendarEvent.md#CalendarEventRun) event ) extends [DispatcherEvent](#DispatcherEvent)
Produced when a local crawler discovers an event. _Does not apply to externally running processes._
### DiscoveredRecommendationEvent( [Recommendation](Recommendation.md#Recommendation) recommendations ) extends [DispatcherEvent](#DispatcherEvent)
Produced when a recommendation is generated.
### NewCalendarEventEvent( [CalendarEventRun](CalendarEvent.md#CalendarEventRun) event ) extends [DispatcherEvent](#DispatcherEvent)
Produced when a new event is added to the system
### UserEvent( [User](User.md#User) user ) extends [DispatcherEvent](#DispatcherEvent)
Produced when a user performs a notable action
### UserLoginEvent( [User](User.md#User) user, token ) extends [UserEvent](#UserEvent)
Procuced when a user logs in
### UserFeedbackEvent( [User](User.md#User) user, feedback ) extends [UserEvent](#UserEvent)
Produced when a user leaves feedback
### NewUserEvent( [User](User.md#User) user ) extends [UserEvent](#UserEvent)
Produced whan a new user is added to the system
### SystemStartEvent() extends [DispatcherEvent](#DispatcherEvent)
Produced exactly once when the system starts
