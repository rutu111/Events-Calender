# Integration
### login( String code )<a id="login"></a>
Attempts to login a user with the given code to the integration. Returns a user object for that user on success and throws an error on failure.
### getSession( String token = `None` )<a id="getSession"></a>
Returns an oauth session for the given token
### getAuthURL( dict scope=None )
returns a string to login to this integration