### Recommendation( [User](User.md#User) user, [CalendarEventRun](#CalendarEventRun) event, float weight )
A recommendation to `user` for `event` with a confidence of `weight`
### Feedback( [User](User.md#User) user, [CalendarEventRun](#CalendarEventRun) event, float rating )
Feedback on `event` from `user` with a score of `rating`
