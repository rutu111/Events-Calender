### User( String userName, [Integration](Integration.md#Integration) integration, integratonId, token=None )<a id="User"></a>
The `User` class reprents any user in the system.
Users should be created internally but are exposed so that type-checking can be done.
