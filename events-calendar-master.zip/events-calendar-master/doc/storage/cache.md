### get( object key )<a id="get"></a>
If `key` was originally a key passed to [put](#put), returns the value associated with it in cache.
If `key` was originally a value passed to [put](#put), returns the key associated with it in cache.

If `key` has not been passed to [put](#put) or the value associated has been flushed from cache, returns None.
Any time the cache fails to return a cached object, the system is expected to fetch the object from storage and call [put](#put) to store it in cache before passing it elsewhere.

### put( object key, object value )<a id="put"></a>
Stores an object in the cache associated with a key.
Objects will remain in the cache until all external references are removed.

### associateKeys ( list keys )<a id="associateKeys"></a>
Returns a `dict` object where each key is found in `keys` and each value is it's associated value in the cache as per the [get](#get) function.
If a key from `keys` is not found in the cache, it will be excluded silently from the returned object.

### associateValues ( list values )<a id="associateValues"></a>
Returns a `dict` object where each value is found in `values` and each key is it's associated value in the cache as per the [get](#get) function.
If a value from `values` is not found in the cache, it will be excluded silently from the returned object.
