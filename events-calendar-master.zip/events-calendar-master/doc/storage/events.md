### getAllCategories()
Returns a list of all categories stored by the system.

### getCalendarEvent(int eventID)
Queries the cache/database given an event ID. Returns a `CalendarEvent` object.

### getAllCalendarEvents()
Queries the cache/database for all events. Returns a list of `CalendarEvent` objects.

### storeCalendarEvent(CalendarEvent event)
Stores the given `CalendarEvent` object in the database and cache.

### updateCalendarEvent(CalendarEvent event)
Updates the given `CalendarEvent` object in the database and cache.

### getVenue(int venueID)
Queries the cache/database given a venue ID. Returns a `Venue` object.

### getAllVenues()
Queries the cache/database for all venues. Returns a list of `Venue` objects.

### storeVenue()
Stores the given `Venue` object in the database and cache.

### updateVenue()
Updates the given `Venue` object in the database and cache.

### getCalendarEventRun(int eventRunID)
Queries the cache/database given an event run ID. Returns a `CalendarEventRun` object.

### getAllCalendarEventRuns()
Queries the cache/database for all event runs. Returns a list of `CalendarEventRun` objects.

### storeCalendarEventRun(CalendarEventRun eventRun)
Stores the given `CalendarEventRun` object in the database and cache.

### updateCalendarEventRun(CalendarEventRun eventRun)
Updates the given `CalendarEventRun` object in the database and cache.

### getPopularEvents()
Queries the cache/database for popular events. Returns a list of `CalendarEvent` objects.