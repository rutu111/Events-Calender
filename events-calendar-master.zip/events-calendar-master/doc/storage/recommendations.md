### getRecommendation(int recommendationID)
Queries the cache/database given a recommendation ID. Returns a `Recommendation` object.

### getAllRecommendationsForUser(User user)
Queries the cache/database for all recommendations given an `User` object. Returns a list of `Recommendation` objects.

### getAllRecommendations()
Queries the cache/database for all recommendations. Returns a list of `Recommendation` objects.

### storeRecommendation(Recommendation recommendation)
Stores the given `Recommendation` object in the database and cache.

### updateRecommendation(Recommendation recommendation)
Updates the given `Recommendation` object in the database and cache.

### getFeedback(int feedbackID)
Queries the cache/database given a feedback ID. Returns a `Feedback` object.

### getFeedbackForUserAndEvent(User user, CalendarEvent event)
Queries the cache/database for all feedback given a `User` and `Event` object. Returns a list of `Feedback` objects.

### getAllFeedback()
Queries the cache/database for all feedback. Returns a list of `Feedback` objects.

### storeFeedback(Feedback feedback)
Stores the given `Feedback` object in the database and cache.

### updateFeedback(Feedback feedback)
Updates the given `Feedback` object in the database and cache.