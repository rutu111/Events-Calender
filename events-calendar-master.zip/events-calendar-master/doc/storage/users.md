### setInterests([User](../objects/User.md#User) user, dict categories)
Sets the users interests to the provided values. Will delete all previous interests before setting new ones.

### getUser(int userID)
Queries the cache/database given a user ID. Returns a `User` object.

### getUserByIntegration(Integration integration, int integration_id)
Queries the cache/database for all users given a integration and integration ID. Returns a list of `User` objects.

### getAllUsers()
Queries the cache/database for all users. Returns a list of `User` objects.

### storeUser(User user)
Stores the given `User` object in the database and cache.

### updateUser(User user)
Updates the given `User` object in the database and cache.