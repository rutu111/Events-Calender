# Views
## login
If a `GET` request is made with the token key set, system will attempt to log the user in with the token value provided. If successful, the user will be redirected to the main page. Otherwise, it will display the error message through the template `login.djt`.

If a `POST` request is made with the token key set, system will attempt to log the user in with the token value provided. The response will always be a JSON file denoting success with the `success` key and, if unsuccessful, more details via the `message` key.

In all other cases, `login.djt` will be rendered without an error message and should prompt the user to login.