# MySQL Setup on Windows

## Install MySQL
Download the MySQL Installer at https://dev.mysql.com/downloads/installer/

When running the installer, install the following:
* MySQL Server
* MySQL Workbench

The installer will ask you for a root password. Take note of this.

## Connect Application to MySQL Server
Open your ```settings.py``` file and ensure it has the following settings, substituting the password to the one set earlier.
```
DATABASE = {
	'hostname': 'localhost',
	'port':     3306,
	'username': 'root',
	'password': '<password>',
	'database': 'events_calendar',
	'charset':  'utf8mb4',
}
```

## Import Schema to MySQL Server
1. Open MySQL Workbench.
2. Connect to the MySQL server using the information set in the installer.
3. Open the ```schema.sql``` file and run it while connected to your MySQL Server.

To input some example events you can optionally open the ```sample.sql``` file and run it while connected to your MySQL Server.

# Using the Server Database
If you find the above too difficult or need run tests on the production database, you can provide the following details to settings to connect to the database maintained by the site itself:
```
DATABASE = {
	'hostname': 'eventscalendar.uk',
	'port':     3306,
	'username': 'events',
	'password': '<password>',
	'database': 'events_calendar',
	'charset':  'utf8mb4',
}
```
Ask @jacobgelling or @andrew-watson-uoa for the password if you don't already have it.
