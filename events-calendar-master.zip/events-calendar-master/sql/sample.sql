INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('afs000asbaba102695645b8c656024db', 'The Hub, 2nd Floor');
INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('mvniaw22baba102695645b8c656024db', 'Hillhead Centre');
INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('14141424baba102695645b8c656024db', 'Codona\'s Theme Park');

INSERT INTO `events_calendar`.`categories` (`category`) VALUES ('Food');
INSERT INTO `events_calendar`.`categories` (`category`) VALUES ('Bowling');

INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('6ccd780cbaba102695645b8c656024db', 'Pizza party', 'Monthly Pizza Party in the Hub for all students!', '#exampleUrl', 'Food', '/image/pizza_example.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('258b6b75332511e88a397085c23b89a1', '6ccd780cbaba102695645b8c656024db', '0', '0', '2018-03-16 17:00:00', '2018-03-16 20:00:00', 'afs000asbaba102695645b8c656024db');
INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('6s4bsrrrbaba102695645b8c656024db', 'Cooking class', 'Cooking class for all students.', '#exampleUrl', 'Food', '/image/cookingclass.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('db85671932a211e88a397085c23b89a1', '6s4bsrrrbaba102695645b8c656024db', '0', '0', '2018-03-17 15:00:00', '2018-03-17 17:00:00', 'mvniaw22baba102695645b8c656024db');
INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('p2df235dbaba102695645b8c656024db', 'Bowling Night!', 'Tonight is a bowling night!', '#exampleUrl', 'Bowling', '/image/bowling_example.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('f6c4639b32a211e88a397085c23b89a1', 'p2df235dbaba102695645b8c656024db', '0', '0', '2018-03-18 17:00:00', '2018-03-18 20:00:00', '14141424baba102695645b8c656024db');
