INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('afs000adbaba102695645b8c656024db', 'Triplekirks');

INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('g85jkktfbaba102695645b8c656024db', 'Pub Crawl', 'Who doesn\'t like a good old pub crawl?', '#exampleUrl', 'Food', '/image/pubcrawl_example.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('b8a4eab8332511e88a397085c23b89a1', 'g85jkktfbaba102695645b8c656024db', false, false, '2018-03-19 21:00:00', '2018-03-19 23:59:00', 'afs000adbaba102695645b8c656024db');
