UPDATE `events_calendar`.`events` SET `description`='Monthly Pizza Party in the Hub for all students! Come along and grab your friends to enjoy good company and, of course, free pizza! This event is for all students and doesn\'t require any membership of any society. Just pop in and enjoy yourself!' WHERE `id`='6ccd780cbaba102695645b8c656024db';

UPDATE `events_calendar`.`events` SET `description`='Cooking class for all students. In these workshops we are teaching students all over UK to make easy and cheap meals that will fill them up and won\'t cost a fortune. This workshop is free of charge and everyone is welcome! However, number of places is limited so don\'t forget to notify us about your participation! :)' WHERE `id`='6s4bsrrrbaba102695645b8c656024db';

UPDATE `events_calendar`.`events` SET `description`='Friday night is a bowling night! Students get special discount, and just for £4.50 you can enjoy unlimited bowling throughout the evening. Don\'t forget your student ID card.' WHERE `id`='p2df235dbaba102695645b8c656024db';

UPDATE `events_calendar`.`events` SET `description`='Who doesn\'t like a good old pub crawl? Don\'t miss a chance to mingle and have a couple of drinks becasue you deserve it! We will start the pub crawl at Triplekirks, and then move towards Union Street for more adventures! Join us!' WHERE `id`='g85jkktfbaba10269564-5b8c656024db';

INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('gg343gfdbaba102695645b8c656024db', 'Infohub, Ground Floor');
INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('io8965ggbaba102695645b8c656024db', 'Meston Building 311');
INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('nvcyte55baba102695645b8c656024db', '43C King\'s Street');
INSERT INTO `events_calendar`.`venues` (`id`, `address`) VALUES ('hebhtetebaba102695645b8c656024db', 'Aberdeen Sports Village');

INSERT INTO `events_calendar`.`categories` (`category`) VALUES ('Physical Activity');
INSERT INTO `events_calendar`.`categories` (`category`) VALUES ('Classes');
INSERT INTO `events_calendar`.`categories` (`category`) VALUES ('Trips');

INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('zawwpgp6baba102695645b8c656024db', 'Trip to Edinburgh', 'Join us for a trip to Edinburgh - Scotland\'s compact, hilly capital. It has a medieval Old Town and elegant Georgian New Town with gardens and neoclassical buildings. Limited number of spaces are available, to find out more and register go to Infohub.', '#exampleUrl', 'Trips', '/image/edinburgh_example.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('db89392b32a211e88a397085c23b89a1', 'zawwpgp6baba102695645b8c656024db', false, false, '2018-03-24 09:00:00', '2018-03-25 21:00:00', 'gg343gfdbaba102695645b8c656024db');

INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('4574f45tbaba102695645b8c656024db', 'Web Development Class', 'Learn Web Development by building websites and mobile apps using HTML, CSS, Javascript, PHP, Python, MySQL and more!', '#exampleUrl', 'Classes', '/image/computing_example.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('132483f7332511e88a397085c23b89a1', '4574f45tbaba102695645b8c656024db', false, false, '2018-03-29 16:00:00', '2018-03-29 19:00:00', 'io8965ggbaba102695645b8c656024db');

INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('asdadsdsbaba102695645b8c656024db', 'Introduction to Creative Writing', 'Use your own creativity and find your very own meaning of creative writing. Creative writers have the power to entertain someone, to make someone laugh, to make someone cry and to make someone think. Join us and this course will help you discover and put into practice your own strategies for living a more creative life.', '#exampleUrl', 'Classes', '/image/writing_example.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('f794dd6132a211e88a397085c23b89a1', 'asdadsdsbaba102695645b8c656024db', false, false, '2018-04-02 13:00:00', '2018-04-02 15:00:00', 'nvcyte55baba102695645b8c656024db');

INSERT INTO `events_calendar`.`events` (`id`, `title`, `description`, `url`, `category`, `thumbnail`) VALUES ('ykukyuykbaba102695645b8c656024db', 'Saturday Morning Meditation', 'The goal of meditation is to focus and quiet your mind - eventually reaching a higher level of awareness and inner calm. This class is available for all people, no matter if you have tried meditating before or not.', '#exampleUrl', 'Physical Activity', '/image/meditation_example.jpg');
INSERT INTO `events_calendar`.`event_runs` (`id`, `event`, `cancelled`, `fully_booked`, `start_date`, `end_date`, `venue`) VALUES ('f6bf9ac432a211e88a397085c23b89a1', 'ykukyuykbaba102695645b8c656024db', false, false, '2018-04-07 10:00:00', '2018-04-07 12:30:00', 'hebhtetebaba102695645b8c656024db');
