-- add some users and feedback to the system

INSERT INTO `events_calendar`.`users` (`id`, `username`, `integration`, `integration_id`, `token`) VALUES ('ji43534obaba102695645b8c656024db', 'User 1', 1, '123456', 'n9c2bnd-a923jf0a-_yf9jb2_78azc');
INSERT INTO `events_calendar`.`users` (`id`, `username`, `integration`, `integration_id`, `token`) VALUES ('onj45odfbaba102695645b8c656024db', 'User 2', 1, '123457', 'n__ma-dmvcvcq789b23dra-A9lgerw');
INSERT INTO `events_calendar`.`users` (`id`, `username`, `integration`, `integration_id`, `token`) VALUES ('lpkfs322baba102695645b8c656024db', 'User 3', 1, '123458', 'olf-haob59h80s0w_kaiof55bb25da');

INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('ji43534obaba102695645b8c656024db', '258b6b75332511e88a397085c23b89a1', 1);
INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('ji43534obaba102695645b8c656024db', 'db85671932a211e88a397085c23b89a1', 0);
INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('onj45odfbaba102695645b8c656024db', '258b6b75332511e88a397085c23b89a1', 1);
INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('onj45odfbaba102695645b8c656024db', 'db85671932a211e88a397085c23b89a1', 0);
INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('ji43534obaba102695645b8c656024db', 'f6c4639b32a211e88a397085c23b89a1', 1);
INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('lpkfs322baba102695645b8c656024db', '258b6b75332511e88a397085c23b89a1', 0);
INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('lpkfs322baba102695645b8c656024db', 'db89392b32a211e88a397085c23b89a1', 1);
INSERT INTO `events_calendar`.`feedback`(`user`, `event`, `rating`) VALUES('lpkfs322baba102695645b8c656024db', '132483f7332511e88a397085c23b89a1', 1);
