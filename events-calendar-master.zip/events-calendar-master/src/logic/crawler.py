from datetime import datetime, timedelta
import json

from scrapy import Spider
from scrapy.crawler import CrawlerProcess
from scrapy.settings import Settings

from objects.CalendarEvent import CalendarEvent, CalendarEventRun, Venue
from objects.DispatcherEvent import CrawlerDiscoveredCalendarEventEvent

from logic.dispatcher import dispatch
from logic.integrations import FACEBOOK

from logic import events # to bind hooks to handle new events

import settings_base as settings

_EARLIESTDATE = datetime(2000, 1, 1) # Earliest date from which to keep events from

class AusaSpider(Spider):	# Spider/Crawler class
	name = "ausacrawler"
	start_urls = [
		"https://www.ausa.org.uk/ents/eventlist/", # Starts here
	]

	def parse(self, response):	 # Follows each month link
		for monthlink in response.css("div#event_dates li a::attr(href)"):
			if monthlink is not None:
				yield response.follow(monthlink, self.parseEventLinks)

	def parseEventLinks(self, response):   # Follows each event link within the month page
		for eventlink in response.css("div.eventlist_day dl dt a.msl_event_name::attr(href)"):
			if eventlink.extract()[0:12] == "/ents/event/":
				if eventlink is not None:
					yield response.follow(eventlink, self.parseEvent)


	def parseEvent(self, response):	 # Gather data about each event
		dict1 = {}
		dict1["title"] = response.css("div#msl_event h1::text").extract_first()
		dict1["location"] = response.css("div.event_location h3::text").extract_first()
		dict1["date"] = response.css("div.event_location h4::text").extract_first()
		dict1["currenturlfortickets"] = response.url
		body = response.css("div#event-body").xpath("child::*[not(self::fieldset) and not(self::img) and not(contains(@id, 'tickets')) and not(contains(@class, 'event_tickets'))]").extract()
		i = 0
		while i < len(body):
			body[i] = body[i].strip()
			i += 1
		dict1["body"] = body
		dict1["image"] = response.urljoin(response.css("div#event-body img::attr(src)").extract_first())
		yield dict1


class AusacrawlerPipeline(object):	 # Takes each item yielded from the all spiders and processes it
	def process_item(self, item, spider):
		if isinstance(spider, AusaSpider): # we're only handling the Ausa spider here
			bodystring = " ".join(item["body"])
			if ausaStrToDate(item["date"])["start"] is None:
				return
			venueObject = Venue(address=item["location"])
			calendarEventObject = CalendarEvent(title=item["title"], owner=None, description=bodystring, thumbnail=item["image"], url=item["currenturlfortickets"], category=None)
			eventRunObject = CalendarEventRun(None, event=calendarEventObject, start=ausaStrToDate(item["date"])["start"], end=ausaStrToDate(item["date"])["end"], venue=venueObject)
			dispatch(CrawlerDiscoveredCalendarEventEvent(eventRunObject))

		return item

class FacebookSpider(Spider):
	name = "facebookcrawler"
	start_urls = [
		"%s/%s/events?access_token=%s|%s&fields=cover,is_canceled,description,end_time,start_time,place,name,id"
		% ("https://graph.facebook.com/v2.7", page, FACEBOOK.getClientId(), FACEBOOK.getClientSecret())
		for page in ['AberdeenAmnesty', 'abdncu']
	]

	def parse(self, response): # parse each events query
		events = json.loads(response.body_as_unicode())
		for event in events["data"]:
			if datetime.strptime(event['start_time'][:19], "%Y-%m-%dT%H:%M:%S") < _EARLIESTDATE:
				return # assuming events are in chronological order, there will be not more events we care about
			yield event

		if "next" in events["paging"]:
			yield response.follow(events["paging"]["next"], self.parse) # crawl the next page



class FacebookcrawlerPipeline(object): # Takes data from events and processes it
	def process_item(self, item, spider):
		if isinstance(spider, FacebookSpider): # we're only handling the Facebook spider here
			if ("place" in item) and ("description" in item) and ("end_time" in item):
				venueObject = Venue(address=item["place"]["name"])
				calendarEventObject = CalendarEvent(title=item["name"], owner=None, url="https://www.facebook.com/events/%s" % item["id"], description=item["description"], category=None, thumbnail=item["cover"]["source"] if "cover" in item else None)

				if "location" in item["place"]:
					if "street" in item["place"]["location"]:
						venueObject.address = venueObject.location["address"] + ', ' + item["place"]["location"]["street"]
					if "longitude" in item["place"]["location"]:
						venueObject.longitude = item["place"]["location"]["longitude"]
						venueObject.latitude = item["place"]["location"]["latitude"]
				if "is_canceled" in item:
					calendarEventObject.cancelled = item["is_canceled"]
				eventRunObject = CalendarEventRun(None, event=calendarEventObject, start=datetime.strptime(item["start_time"][:19], "%Y-%m-%dT%H:%M:%S"), end=item["end_time"][:19], venue=venueObject)
				dispatch(CrawlerDiscoveredCalendarEventEvent(eventRunObject))

		return item

def ausaStrToDate(dateString):
	startAndEndDict = {"start": None, "end": None}
	words = dateString.split()
	if len(words) > 7:
		try:
			if ("noon" in words) or ("midnight" in words):
				date = datetime.strptime(dateString, "%A %d %B %Y at "+dateString[dateString.index(' at')+3:])
				done = [1, 1]
				if words[5] == "noon":
					startDate = date.replace(hour=12)
					done[0] = 0
				if words[7] == "noon":
					endDate = date.replace(hour=12)
					done[1] = 0
				if words[5] == "midnight":
					startDate = date + timedelta(days=1)
					done[0] = 0
				if words[7] == "midnight":
					endDate = date + timedelta(days=1)
					done[1] = 0
				if done[0] == 1:
					if len(words[5]) > 5:
						startDate = datetime.strptime(dateString, "%A %d %B %Y at %I:%M%p"+dateString[dateString.index('-')-1:])
					else:
						startDate = datetime.strptime(dateString, "%A %d %B %Y at %I%p"+dateString[dateString.index('-')-1:])
				if done[1] == 1:
					if len(words[7]) > 5:
						endDate = datetime.strptime(dateString, "%A %d %B %Y at "+dateString[dateString.index(' at')+3:dateString.index('-')+2]+"%I:%M%p")
					else:
						endDate = datetime.strptime(dateString, "%A %d %B %Y at "+dateString[dateString.index(' at')+3:dateString.index('-')+2]+"%I%p")
				startAndEndDict["start"] = startDate
				startAndEndDict["end"] = endDate
				return startAndEndDict
			else:
				if len(words[5]) > 5:
					startDate = datetime.strptime(dateString, "%A %d %B %Y at %I:%M%p"+dateString[dateString.index('-')-1:])
				else:
					startDate = datetime.strptime(dateString, "%A %d %B %Y at %I%p"+dateString[dateString.index('-')-1:])
				if len(words[7]) > 5:
					endDate = datetime.strptime(dateString, "%A %d %B %Y at "+dateString[dateString.index(' at')+3:dateString.index('-')+2]+"%I:%M%p")
				else:
					endDate = datetime.strptime(dateString, "%A %d %B %Y at "+dateString[dateString.index(' at')+3:dateString.index('-')+2]+"%I%p")
				startAndEndDict["start"] = startDate
				startAndEndDict["end"] = endDate
				if startDate > endDate: # This would only happen if Ausa messed up
					raise ValueError("Start time after end time")
		except (ValueError, IndexError) as error:
			startAndEndDict["start"] = None
			print(error)
	return startAndEndDict

def crawl():
	crawlerSettings = Settings()
	crawlerSettings.setmodule(settings)
	process = CrawlerProcess(settings=crawlerSettings, install_root_handler=False)

	process.crawl(AusaSpider)
	process.crawl(FacebookSpider)
	process.start() # blocks the process
