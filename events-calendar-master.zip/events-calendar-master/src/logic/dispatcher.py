from inspect import getmro, isclass

from objects.DispatcherEvent import DispatcherEvent

_REGISTERED_CALLBACKS = {} # maps classes extending DispatcherEvent to lists of callback functions that have been regitered

def on(eventClass, callback):
	assert isclass(eventClass) and issubclass(eventClass, DispatcherEvent) # verify that argument is actually a class extending DispatcherEvent
	assert not isclass(callback) and callable(callback) # verify that the callback is actually callable
	if eventClass not in _REGISTERED_CALLBACKS: # if there are no callbacks registered
		_REGISTERED_CALLBACKS[eventClass] = [] # setup an array to hold new callbacks
	_REGISTERED_CALLBACKS[eventClass].append(callback) # put a callback into the array

def when(*args):
	def wrappedWhen(fn):
		for event in args:
			on(event, fn)
		def wrappedFunction(*args2):
			return fn(*args2)
		return wrappedFunction
	return wrappedWhen

def dispatch(event: DispatcherEvent):
	classes = getmro(type(event)) #returns a list (tuple) of all base classes of a class (including itself).
	errors = []
	for c in classes:
		if issubclass(c, DispatcherEvent) and c in _REGISTERED_CALLBACKS: # if the current base class is of type event and the base class has reigstered callbacks
			for callback in _REGISTERED_CALLBACKS[c]:
				try:
					callback(event)
				except Exception as e: # in case the callback errors, we catch it to allow the rest of the listeners a chance to execute
					errors.append(e)
	if errors: # empty lists evaluate to false, so this is true if the list has at least one element
		if len(errors) == 1:
			raise Exception("An error occured while processing an event") from errors[0]
		else:
			raise Exception("One or more errors have occured: \n" + '\n'.join([str(e) for e in errors])) # raise an exception to say that some listeners errored-out
