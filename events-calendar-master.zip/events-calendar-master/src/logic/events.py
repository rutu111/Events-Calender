from datetime import datetime, timedelta
from Levenshtein import ratio

import requests

from objects.DispatcherEvent import CrawlerDiscoveredCalendarEventEvent, NewCalendarEventEvent, UserFeedbackEvent, SystemStartEvent
from objects.CalendarEvent import CalendarEvent, CalendarEventRun, Venue

from logic.dispatcher import when, dispatch

from storage.events import getCalendarEventRun as s_getEventRun, getPopularEvents as s_getPopularEvents, getAllCalendarEvents as s_getAllCalendarEvents, getAllCalendarEventRuns as s_getAllCalendarEventRuns, storeCalendarEventRun, storeCalendarEvent, storeVenue, updateVenue, updateCalendarEvent, updateCalendarEventRun, getAllVenues, deleteCalendarEventRun, getAllCategories as s_getAllCategories
from storage.recommendations import getFeedbackForUserAndEvent


def getPopularEvents():
	return s_getPopularEvents()

def getEvents() -> [CalendarEvent]: # returns an array of CalendarEvents (is this syntax correct? I thought it should be Iterable[CalendarEvent])
	return s_getAllCalendarEvents()

def getEventRuns() -> [CalendarEventRun]:
	return s_getAllCalendarEventRuns()

def getEvent(eventID) -> CalendarEventRun:
	return s_getEventRun(eventID)

def _passesFilter(event, filters):
	user = filters.get("user")
	if "search" in filters:
		words = filters["search"].lower().split()
		if words:
			matched = [word for word in words if word in event.title.lower()]
			if len(matched)/len(words) < 2/3: # if less than 2/3rds of the words were found in the event title then filter it out
				return False

	if "month" in filters:
		if "FilterSubmitted" in filters:
			pass
		else:
			if event.start.strftime("%B %Y") != filters["month"]:
				return False
	if "categories" in filters:
		if str(event.category) not in filters["categories"]:
			return False
	if "users" in filters:
		passed = False
		for userType in filters["users"]:
			if userType == "other":
				if (user is None) or (user is not event.owner):
					passed = True
			elif userType == "current":
				if (user is not None) and (user is event.owner):
					passed = True
			elif userType == "none":
				if event.owner is None:
					passed = True
		if not passed:
			return False
	if "going" in filters:
		feedback = getFeedbackForUserAndEvent(user, event)
		if (feedback is None or feedback.rating == 0 or event.start < datetime.now()):
			return False
	return True

def filterEvents(events, filters):
	return [e for e in events if _passesFilter(e, filters)]

def getCategories():
	return s_getAllCategories()

def compareVenues(v1, v2):
	# Prevent fuzzy matching to deny malicious walking of venues away from what's intended
	# if v1.location["address"] and v2.location["address"]:
	# 	return ratio(v1.location["address"], v2.location["address"]) > 0.8
	# else:
	return v1.location == v2.location and v1.url == v2.url and v1.description == v2.description

@when(CrawlerDiscoveredCalendarEventEvent)
def insertNewEvent(discoveredEventEvent):
	eventobject = discoveredEventEvent.event
	events = s_getAllCalendarEventRuns()
	venues = getAllVenues()

	matchingVenues = [v for v in venues if compareVenues(v, eventobject.venue)]
	if matchingVenues: # if no venue exists which is the same as the new one
		matchingVenues[0].location = eventobject.venue.location
		matchingVenues[0].url = eventobject.venue.url
		matchingVenues[0].description = eventobject.venue.description
		eventobject.venue = matchingVenues[0]
		updateVenue(eventobject.venue)
	else:
		storeVenue(eventobject.venue)

	for event in events:
		# TODO maybe consider delays and time changes?
		if (eventobject.title == event.title) and (eventobject.description == event.description) and (eventobject.start == event.start) and (eventobject.end == event.end) and (eventobject.thumbnail == event.thumbnail) and (eventobject.owner == event.owner) and (eventobject.location["address"] == event.location["address"]) and (eventobject.url == event.url):
			return
		elif (eventobject.start == event.start) and (eventobject.end == event.end) and (eventobject.thumbnail == event.thumbnail) and (eventobject.owner == event.owner) and (ratio(eventobject.url, event.url) > 0.8) and (ratio(eventobject.title, event.title) > 0.8) and (ratio(eventobject.description, event.description) > 0.8): # I removed check for similarities in event address because some ausa events use "TBC" if they are going to update the event in future to include proper address
			event.description = eventobject.description
			event.title = eventobject.title
			event.url = eventobject.url

			updateCalendarEvent(event.getBase())
			updateCalendarEventRun(event)
			return

	storeCalendarEvent(eventobject.getBase())
	storeCalendarEventRun(eventobject)
	dispatch(NewCalendarEventEvent(eventobject))

def createEvent(event):
	if not [v for v in getAllVenues() if compareVenues(v, event.venue)]: # if no venue exists which is the same as the new one
		storeVenue(event.venue)
	storeCalendarEvent(event.getBase())
	storeCalendarEventRun(event)

def editEvent(oldEvent, newEvent):
	if oldEvent.venue is not newEvent.venue:
		if not [v for v in getAllVenues() if compareVenues(v, newEvent.venue)]: # if no venue exists which is the same as the new one
			storeVenue(newEvent.venue)
		oldEvent.venue = newEvent.venue

	oldEvent.title = newEvent.title
	oldEvent.url = newEvent.url
	oldEvent.description = newEvent.description
	oldEvent.category = newEvent.category
	oldEvent.owner = newEvent.owner
	oldEvent.thumbnail = newEvent.thumbnail
	oldEvent.image = newEvent.image

	oldEvent.start = newEvent.start
	oldEvent.end = newEvent.end
	oldEvent.cancelled = newEvent.cancelled
	oldEvent.fullyBooked = newEvent.fullyBooked

	matchingVenues = [v for v in getAllVenues() if compareVenues(v, oldEvent.venue)]
	if matchingVenues: # if no venue exists which is the same as the new one
		oldEvent.venue = matchingVenues[0]
		updateVenue(oldEvent.venue)
	else:
		oldEvent.venue = newEvent.venue
		storeVenue(oldEvent.venue)

	updateCalendarEvent(oldEvent.getBase())
	updateCalendarEventRun(oldEvent)

def updateEvent(e):
	updateCalendarEvent(e.getBase())
	updateCalendarEventRun(e)

def searchForEvent(eventString):
	words = eventString.split()
	if words:
		events = s_getAllCalendarEventRuns()
		returnList = []
		for event in events:
			temp = 0
			for word in words:
				if word.lower() in event.title.lower():
					temp += 1
			if temp/len(words) > 2/3: # if more than 2/3rds of the words were found in the event title then it's good enough to show
				returnList.append([event, temp/len(words)])
		returnList.sort(key=lambda x: x[1], reverse=True)
		return returnList

def validateEvent(data):
	if "event_name" not in data:
		raise ValueError("missing name for event")
	name = data["event_name"]
	if not name:
		raise ValueError("invalid event name provided")

	if "message" not in data:
		raise ValueError("missing description for event")
	description = data["message"]

	if "start_date" not in data or "start_time" not in data:
		raise ValueError("missing start time for event")
	try:
		start = datetime.strptime("%s %s" % (data["start_date"], data["start_time"]), "%d/%m/%Y %H:%M")
	except Exception as e:
		raise Exception("invalid start time for event") from e

	if "end_date" in data or "end_time" in data:
		if "end_date" not in data or "end_time" not in data:
			raise ValueError("missing end time for event")
		end = datetime.strptime("%s %s" % (data["start_date"], data["start_time"]), "%d/%m/%Y %H:%M")
	else:
		end = start

	if "category" not in data:
		raise ValueError("missing category for event")
	category = data["category"]
	if category and category not in getCategories():
		raise ValueError("invalid category provided")

	if "event_location" not in data:
		raise ValueError("missing location for event")
	address = data["event_location"]
	if not address:
		raise ValueError("invalid event address provided")

	# TODO file upload

	return CalendarEventRun(None, CalendarEvent(name, description, None, category=category), start, end, Venue(address))

def deleteEvent(e):
	deleteCalendarEventRun(e)


_lastCrawl = datetime(2018, 1, 1)
@when(UserFeedbackEvent, SystemStartEvent)
def asyncCrawl(_, override=False):
	global _lastCrawl
	if (_lastCrawl < datetime.now() - timedelta(seconds = 300)) or override:
		_lastCrawl = datetime.now()

		for crawler in ["ausacrawler", "facebook"]:
			requests.post('http://localhost:6800/schedule.json', data=[
			    ("project", "events-calendar-crawler"),
				("spider", crawler)
			])
