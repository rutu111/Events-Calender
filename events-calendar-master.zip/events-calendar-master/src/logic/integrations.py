from abc import ABC, abstractmethod
from json import loads as loadJSON

from objects.User import User
from objects.Integration import Integration

try:
	from settings import INTEGRATIONS as integrations
except ImportError as e:
	raise ImportError("Unable to load integrations data from settings; are you sure you set it up correctly?") from e

class _FacebookIntegration(Integration):
	def getClientId(self):
		return integrations["facebook"]["id"]

	def getClientSecret(self):
		return integrations["facebook"]["secret"]

	def getTokenURL(self):
		return "https://graph.facebook.com/oauth/access_token"

	def getBaseAuthURL(self):
		return "https://www.facebook.com/dialog/oauth"

	def getUserDetails(self, token):
		r = self.getSession(token).get("https://graph.facebook.com/me?fields=id,name") # make a request to the specified url using the token
		# "User" below is the username: how this is aquired will have to be discussed.
		data = loadJSON(r.content)
		return User(data["name"], "facebook", data["id"], token=token["access_token"]) # use the request to fetch the data as json and get the id from it to create a new user object

FACEBOOK = _FacebookIntegration()
