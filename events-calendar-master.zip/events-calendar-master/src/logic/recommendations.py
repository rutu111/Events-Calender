import pandas
from surprise import Reader, SVD, Dataset
from surprise.model_selection import cross_validate
from datetime import datetime, timedelta
from threading import Thread

from objects.DispatcherEvent import DiscoveredRecommendationEvent, UserFeedbackEvent, UserEvent
from objects.Recommendation import Recommendation

from logic.dispatcher import dispatch, when
from logic.events import getCategories

from storage.recommendations import getAllFeedback, storeFeedback, getAllRecommendations, getAllRecommendationsForUser, storeRecommendation, getFeedbackForUserAndEvent, updateFeedback, updateRecommendation
from storage.events import getAllCalendarEventRuns
from storage.users import getAllUsers


_lastRecommendationGeneration = datetime(2018, 1, 1)

def getRecommendedEvents(user): # used to get all recommended events for a given user
	calendarEventRunList = getAllCalendarEventRuns()
	recommendedEventRunList = []
	allRecommendationsForUser = getAllRecommendationsForUser(user)
	allRecommendationsForUser.sort(key=lambda x: x.weight, reverse=True)
	for recommendation in allRecommendationsForUser:
		for event in calendarEventRunList:
			if (recommendation.event is event.getBase()) and (event.start > datetime.now()) and (getFeedbackForUserAndEvent(user, event) is None): # if event is in future and user hasn't/isnt attending it
				recommendedEventRunList.append(event)
	return recommendedEventRunList

@when(UserEvent)
def generateRecommendationsAsync(_):
	Thread(target=generateRecommendations).start()


def generateRecommendations(override=False, adminTest=False): # Generates recommendations for all users at once
	global _lastRecommendationGeneration # What time recommendations were last generated
	if (_lastRecommendationGeneration < datetime.now() - timedelta(seconds = 300)) or override: # if last generation was at least 5 minutes ago or if the time constraint is being overridden
		_lastRecommendationGeneration = datetime.now() # set last generation to now
		feedback = getAllFeedback()
		ratingsDict = {'user': [f.user for f in feedback], 'event': [f.event for f in feedback], 'rating': [f.rating for f in feedback]} # create a dictionary of feedback with which to generate recommendations with

		ratingsDataframe = pandas.DataFrame(ratingsDict) # Create pandas dataframe from the ratings dict

		reader = Reader(rating_scale=(0, 1)) # Scale for the ratings
		data = Dataset.load_from_df(ratingsDataframe[['user', 'event', 'rating']], reader) # Create dataset from pandas dataframe to be used by algorithm

		trainset = data.build_full_trainset() # Train algorithm with all of the data
		algo = SVD()  # Using SVD algorithm

		if adminTest == True: # test the svd algorithm and its settings against the ratings in our database to see how accurate they are without taking category weighting into account
			cross_validate(algo, data, measures=['RMSE', 'MAE'], cv=5, verbose=True)
			return

		algo.fit(trainset)

		testset = trainset.build_anti_testset() # Test set will be all user/event pairs where ratings don't exist
		predictions = algo.test(testset) # Returns predictions of ratings for these pairs

		implicitRatingsDict = processCategoryWeightingsForAllUsers() # generate implicit category weightings by considering the categories of the events that a user attended (If generating recommendations takes too long take this out of the function and do it less often)
		for prediction in predictions: # For each prediction get event and user objects to then create an instance of Recommendation then dispatch this instance
			event = prediction[1]
			user = prediction[0]
			weightingEst = prediction[3] # This is the estimated weighting for the recommendation
			if event.category is not None: # If the event has a category then take the weighting of this category for the user into account
				for categoryWeightList in implicitRatingsDict[user]:
					if categoryWeightList[0] == event.category:
						weightingEst = (5*weightingEst + 1*categoryWeightList[1])/(5+1) # we dont want the category weighting to have too much of an overpowering effect so we lessen this but still consider it (1 can be removed and 5+1=6 but leaving there incase it needs to be changed)
						break
			else:
				weightingEst = (5*weightingEst + 1*0.5)/(5+1) # If the event doesn't have a category then use the average/defualt category weighting, 0.5
			recommendationobject = Recommendation(user, event.getBase(), float(weightingEst)) # create a recommendation instance
			dispatchEvent = DiscoveredRecommendationEvent(recommendationobject)
			dispatch(dispatchEvent)

def processCategoryWeightingsForAllUsers(): # order category weightings of 1 and 0.1 but keep the lowest 1 higher than the highest 0.1
	allUsersList = getAllUsers()
	categories = getCategories()
	dictOfUsersAndCategories = dict.fromkeys(allUsersList)
	listOfFeedback = getAllFeedback()
	listOfCategoriesAndNumberOfFeedback = []
	for category in categories:
		listOfCategoriesAndNumberOfFeedback.append([category, 0])
	for user in dictOfUsersAndCategories:
		dictOfUsersAndCategories[user] = list(listOfCategoriesAndNumberOfFeedback)
	for feedback in listOfFeedback:
		if feedback.event.category != None:
			if feedback.rating == 1:
				for j in range(len(dictOfUsersAndCategories[feedback.user])):
					if dictOfUsersAndCategories[feedback.user][j][0] == feedback.event.category:
						dictOfUsersAndCategories[feedback.user][j][1] = dictOfUsersAndCategories[feedback.user][j][1] + 1
						# dictOfUsersAndCategories is now a dictionary where key is user and value is list of lists where the lists are [category, numberOfPositiveFeedbackForEventWithCategory]
	numberOfCategories = len(categories)

	for user in dictOfUsersAndCategories:
		dictOfUsersAndCategories[user].sort(key=lambda x: x[1], reverse=True)
		numberOf1s=0
		numberOf01s=0
		for category in categories:
			userCategory = user.categories.get(category, 0.5) # 0.5 being the default value
			if userCategory == 1:
				numberOf1s += 1
			if userCategory == 0.1:
				numberOf01s += 1
		if (numberOf1s == 0) and (numberOf01s == 0): # if users category weightings are default (all 0.5) then do following
			amountDefault = 1 # starts here and sets the weighting of the highest ranked category to this
			for categoryWeightList in dictOfUsersAndCategories[user]:
				categoryWeightList[1] = amountDefault
				amountDefault -= 0.2/numberOfCategories # as we work our way through the ranks we give them lower and lower ratings but keep them between 1 and 0.8
		else:
			amount1 = 1 # the categories the user chose to like starts at this
			amount01 = 0.3 # the categories the user chose not to like starts at this (we'd like to keep a gap between the weightings of these 2)
			for categoryWeightList in dictOfUsersAndCategories[user]:
				if user.categories[categoryWeightList[0]] == 1: # if the user liked this category then set the weighting to 1-X depending on what rank the category has
					categoryWeightList[1] = amount1
					amount1 -= 0.2/numberOf1s # each next category weighting will be 0.2/numberOf1s less until minimum of 0.8 weighting
				elif user.categories[categoryWeightList[0]] == 0.1: # if the user didnt choose to like this category then set the weighting to 0.3-Y depending on what rank the category has
					categoryWeightList[1] = amount01
					amount01 -= 0.2/numberOf01s # down to min of 0.1

	return dictOfUsersAndCategories


@when(UserFeedbackEvent) # When a user gives feedback do the following
def processFeedback(feedbackEvent):
	feedback = feedbackEvent.feedback
	allfeedback = getAllFeedback()
	for feedbackiteration in allfeedback:
		if (feedbackiteration.user == feedback.user) and (feedbackiteration.event == feedback.event):
			if feedbackiteration.rating != feedback.rating: # if the rating is different then update it
				feedbackiteration.rating = feedback.rating
				updateFeedback(feedbackiteration)
			return
	storeFeedback(feedback) # if the feedback is new then store it
	return

@when(DiscoveredRecommendationEvent) # when a recommendation is generated do the following
def processRecommendation(recommendationEvent):
	recommendation = recommendationEvent.recommendation
	recommendationList = getAllRecommendations()
	for recommendationObject in recommendationList:
		if (recommendationObject.user == recommendation.user) and (recommendationObject.event == recommendation.event):
			if recommendationObject.weight != recommendation.weight:
				recommendationObject.weight = recommendation.weight # if the weighting is different then update it
				updateRecommendation(recommendationObject)
			return
	storeRecommendation(recommendation) # if the recommendation is new then store it

def getFeedbackForUser(user):
	return [f for f in getAllFeedback() if f.user == user]

def getPositiveEvents(user):
	return [f.event for f in getFeedbackForUser(user) if f.rating == 1]

def getNegativeEvents(user):
	return [f.event for f in getFeedbackForUser(user) if f.rating == 0]

def getFeedbackForEvent(event):
	return [f for f in getAllFeedback() if f.event is event]

def getPositiveFeedbackCount(event):
	return len([1 for f in getFeedbackForEvent(event) if f.rating == 1])

def getNegativeFeedbackCount(event):
	return len([1 for f in getFeedbackForEvent(event) if f.rating == 0])
