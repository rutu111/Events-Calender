import unittest
from datetime import datetime

from objects.DispatcherEvent import CrawlerDiscoveredCalendarEventEvent
from objects.CalendarEvent import CalendarEventRun

from logic.crawler import crawl, ausaStrToDate
from logic import dispatcher

class TestCrawler(unittest.TestCase):
	def setUp(self):
		self.events = []
		dispatcher._registeredCallbacks = {} # forcibly reset callbacks
		self.dates = [
			("Tuesday 20 March 2019 at 9pm - 11pm", datetime(2019, 3, 20, 21, 0), datetime(2019, 3, 20, 23, 0)),
			("Monday 19 March 2018 at noon - 1pm", datetime(2018, 3, 19, 12, 0), datetime(2018, 3, 19, 13, 0)),
			("Thursday 01 March 2018 at 10am - noon", datetime(2018, 3, 1, 10, 0), datetime(2018, 3, 1, 12, 0)),
			("Thursday 01 February 2018 at noon - midnight", datetime(2018, 2, 1, 12, 0), datetime(2018, 2, 2, 0, 0)),
			("Saturday 02 February 2019 at 1am - 3am", datetime(2019, 2, 2, 1, 0), datetime(2019, 2, 2, 3, 0)),
			("Friday 22 June 2018 at 7pm - 11:59pm", datetime(2018, 6, 22, 19, 0), datetime(2018, 6, 22, 23, 59)) # this date showed up from the crawler and generated an error.
		]

	def tearDown(self):
		del self.events

	def callback(self, e):
		self.events.append(e.event)

	def test_crawl(self):
		dispatcher.on(CrawlerDiscoveredCalendarEventEvent, self.callback)
		crawl()
		self.assertTrue(self.events, "Crawler should collect at least one event")
		for event in self.events:
			self.assertIsInstance(event, CalendarEventRun)

	def test_ausaStrToDate(self):
		for (datestring, start, end) in self.dates:
			date = ausaStrToDate(datestring)
			self.assertEqual(date["start"], start)
			self.assertEqual(date["end"], end)
		self.assertEqual(ausaStrToDate("Thursday 01 February 2018 at 3pm - 1pm")["start"], None)
