from unittest import TestCase

from objects.DispatcherEvent import DispatcherEvent, NewCalendarEventEvent
from objects.CalendarEvent import CalendarEvent

import logic.dispatcher

class TestDispatcher(TestCase):
	def setUp(self):
		self.testArgs = [None, 0, 1, "", "abc", object]
		self.callbackRan = False
		self.testEvent = NewCalendarEventEvent(CalendarEvent("Test Event", "Description", "", "All"))

	def tearDown(self):
		logic.dispatcher._REGISTERED_CALLBACKS = {} # forcible reset

	def callback(self, event):
		self.callbackRan = True
		if not isinstance(event, DispatcherEvent):
			raise TypeError("event was not an instance of DispatcherEvent")

	def test_on(self):
		for a in self.testArgs:
			self.assertRaises(AssertionError, logic.dispatcher.on, a, self.callback)
			self.assertRaises(AssertionError, logic.dispatcher.on, NewCalendarEventEvent, a)
			for b in self.testArgs:
				self.assertRaises(AssertionError, logic.dispatcher.on, a, b)

		try:
			logic.dispatcher.on(NewCalendarEventEvent, self.callback)
		except Exception as e:
			self.fail(e)

	def test_dispatch(self):
		try:
			logic.dispatcher.on(NewCalendarEventEvent, self.callback)
		except Exception:
			self.fail("Cannot test dispatch function as event listener failed to register")

		self.assertFalse(self.callbackRan, "Cannot test dispatch function as event listener registered incorrectly (was run before any events were dispached)")


		for a in self.testArgs:
			try:
				logic.dispatcher.dispatch(a)
			except Exception:
				self.fail("failed to safely dispatch invalid event ("+str(a)+")")
			self.assertFalse(self.callbackRan, "dispatcher triggered listener with invalid event ("+str(a)+")")

		try:
			logic.dispatcher.dispatch(self.testEvent)
		except Exception:
			self.fail("failed to safely dispatch valid event")
		self.assertTrue(self.callbackRan, "dispatcher failed to trigger listener with valid event")

	def test_when(self):
		try:
			self.assertTrue(callable(logic.dispatcher.when(NewCalendarEventEvent)(self.callback)))
		except Exception as e:
			self.fail(e)

	def test_dispatchWhen(self):
		try:
			logic.dispatcher.when(NewCalendarEventEvent)(self.callback)
		except Exception:
			self.fail("Cannot test dispatch function as event listener failed to register")

		self.assertFalse(self.callbackRan, "Cannot test dispatch function as event listener registered incorrectly (was run before any events were dispached)")

		for a in self.testArgs:
			try:
				logic.dispatcher.dispatch(a)
			except Exception:
				self.fail("failed to safely dispatch invalid event ("+str(a)+")")
			self.assertFalse(self.callbackRan, "dispatcher triggered listener with invalid event ("+str(a)+")")

		try:
			logic.dispatcher.dispatch(self.testEvent)
		except Exception:
			self.fail("failed to safely dispatch valid event")
		self.assertTrue(self.callbackRan, "dispatcher failed to trigger listener with valid event")