import unittest

from objects.CalendarEvent import CalendarEvent, CalendarEventRun
from objects.User import User

from logic.events import getEvents, getEventRuns, getPopularEvents

from storage.events import getAllCalendarEvents as s_getAllCalendarEvents, getAllCalendarEventRuns as s_getAllCalendarEventRuns, getPopularEvents as s_getPopularEvents

class TestEvents(unittest.TestCase):
	def setUp(self):
		self.user = User("TestUser", None, 0)

	def tearDown(self):
		pass

	def test_getEvents(self):
		# the getEvents() function doesnt take any arguments, so test for the output (return value)
		# check if logic.events.getEvents() is iterable
		events = getEvents()
		self.assertTrue(isinstance(events, list))

		# check for each event in a list of events from storage whether event is an instance of CalendarEvent class
		for event in events:
			self.assertIsInstance(event, CalendarEvent)

		# check that the value is the same as the one returned by storage
		self.assertEqual(events, s_getAllCalendarEvents())

	def test_getEventRuns(self):
		# the getEventRuns() function doesnt take any arguments, so test for the output (return value)
		# check if logic.events.getEventRuns() is iterable
		events = getEventRuns()
		self.assertTrue(isinstance(events, list))

		# check for each event in a list of events from storage whether event is an instance of CalendarEvent class
		for event in events:
			self.assertIsInstance(event, CalendarEventRun)

		# check that the value is the same as the one returned by storage
		self.assertEqual(events, s_getAllCalendarEventRuns())

	def test_getPopularEvents(self):
		# the getEvents() doesnt take any arguments, so test for the output (return value)
		# check if storage.events.getPopularEvents() is iterable
		events = getPopularEvents()
		self.assertTrue(isinstance(events, list))

		# check for each event in a list of popular events from storage whether event is an instance of CalendarEvent class
		for event in events:
			self.assertIsInstance(event, CalendarEventRun) # TODO decide if popular events should be CalendarEvent or CalendarEventRun

		# check that the value is the same as the one returned by storage
		self.assertEqual(events, s_getPopularEvents())

	# TODO test filter + categories
