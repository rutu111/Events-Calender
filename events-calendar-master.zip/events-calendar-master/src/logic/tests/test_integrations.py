import unittest
from unittest import mock

from objects.Integration import Integration

from logic.integrations import _FacebookIntegration, FACEBOOK

class TestIntegration(unittest.TestCase):

	def setUp(self):
		pass

	def tearDown(self):
		pass

	def test_isSubclass(self):
		self.assertTrue(issubclass(_FacebookIntegration, Integration))

	# check if correct TokenURL is returned
	def test_getTokenURL(self):
		self.assertEqual(FACEBOOK.getTokenURL(), "https://graph.facebook.com/oauth/access_token")

	# check if correct BaseAuthURL is returned
	def test_getBaseAuthURL(self):
		self.assertEqual(FACEBOOK.getBaseAuthURL(), "https://www.facebook.com/dialog/oauth")

	def getUserDetails(self, token):
		# check correct input - token
		# check for the output

		# unfinished, approximate test
		# self.assertIsInstance(self.facebook_instance.getUserDetails(<testing token>), User)
		pass
