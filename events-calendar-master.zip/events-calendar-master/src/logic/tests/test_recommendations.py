import unittest

from objects.CalendarEvent import CalendarEvent
from objects.User import User

from logic.recommendations import getRecommendedEvents

from storage.recommendations import getAllRecommendations as s_getAllRecommendations

class TestEvents(unittest.TestCase):
	def setUp(self):
		self.user = User("TestUser", None, 0) # TODO fetch a proper user

	def tearDown(self):
		pass

	def test_getRecommendedEvents(self):
		# check if the length of list of recommneded events is less or equal to 5
		self.assertLessEqual(len(getRecommendedEvents(self.user)), 5) # a <= 5

		# check for each event in a list of recommended events whether event is an instance of CalendarEvent class
		events = getRecommendedEvents(self.user)
		for event in events:
			self.assertIsInstance(event, CalendarEvent)

		# check that the value is the same as the one returned by storage
		self.assertTrue(set(events).issubset([r.event for r in s_getAllRecommendations()])) # TODO reimplement if changed in logic
