import unittest

from objects.User import User

from logic.users import getUser

from storage.users import getUser as s_getUser

class TestUsers(unittest.TestCase):
# get the user directly from db
	def setUp(self):
		pass

	def tearDown(self):
		pass

	# TODO everything frankly
