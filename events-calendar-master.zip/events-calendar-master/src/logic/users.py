from objects.Integration import Integration, LoginURL
from objects.DispatcherEvent import UserFeedbackEvent, UserLoginEvent
from objects.Recommendation import Feedback

from logic.integrations import FACEBOOK
from logic.dispatcher import dispatch, when

from storage.users import getUserByIntegration, getAllUsers as s_getAllUsers, storeUser, updateUser, setInterests as s_setInterests

def getUser(integration, integrationId):
	return getUserByIntegration(integration, integrationId)

def getAllUsers():
	return s_getAllUsers()

def authenticate(authCode, integration: Integration = FACEBOOK):
	user = integration.login(authCode)
	dispatch(UserLoginEvent(user, user.token))
	return user

def getLoginURL(scope=None, integration: Integration = FACEBOOK) -> LoginURL:
	return integration.getAuthURL(scope)

def doFeedback(user, event, rating):
	dispatch(UserFeedbackEvent(user, Feedback(user, event, rating)))

@when(UserLoginEvent)
def addOrUpdateUser(userEvent):
	user = userEvent.user
	systemUser = getUser(user.integration, user.integrationId)
	if systemUser is None:
		storeUser(user)
	else:
		systemUser.token = userEvent.token
		systemUser.name = user.name
		updateUser(systemUser)

# TODO if there's time, do this properly using password hashing, multiple users, the database, etc (there wont be time I just want to note that this is _not_ how to do things)
def adminLogin(username, password):
	try:
		from settings_base import ADMIN_USERNAME as adminUsername, ADMIN_PASSWORD as adminPassword
	except ImportError as e:
		raise ImportError("Unable to load admin credentials from settings") from e
	return username == adminUsername and password == adminPassword

def setInterests(user, interests):
	s_setInterests(user, interests)
