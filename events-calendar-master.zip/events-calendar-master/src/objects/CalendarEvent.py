class CalendarEvent(object):
	def __init__(self, title, description, url, category=None, owner=None, thumbnail=None, image=None):
		self.title = title
		self.url = url
		self.description = description
		self.category = category
		self.owner = owner
		self.thumbnail = thumbnail or image
		self.image = image or thumbnail

	@property
	def isUserCreated(self):
		return self.owner is not None

class CalendarEventRun(object):
	def __init__(self, referenceID, event, start, end, venue):
		self.id = referenceID
		self._event = event
		self.start = start
		self.end = end
		self.venue = venue
		self.cancelled = False # these will need to be set after instantiation if the default is incorrect.
		self.fullyBooked = False

	def getBase(self):
		return self._event

	@property
	def title(self):
		return self._event.title

	@title.setter
	def title(self, value):
		self._event.title = value

	@property
	def url(self):
		return self._event.url

	@url.setter
	def url(self, value):
		self._event.url = value

	@property
	def description(self):
		return self._event.description

	@description.setter
	def description(self, value):
		self._event.description = value

	@property
	def owner(self):
		return self._event.owner

	@owner.setter
	def owner(self, value):
		self._event.owner = value

	@property
	def category(self):
		return self._event.category

	@category.setter
	def category(self, value):
		self._event.category = value

	@property
	def thumbnail(self):
		return self._event.thumbnail

	@thumbnail.setter
	def thumbnail(self, value):
		self._event.thumbnail = value

	@property
	def image(self):
		return self._event.image

	@image.setter
	def image(self, value):
		self._event.image = value

	# this isn't a required property, but it is a convenience.
	@property
	def location(self):
		return self.venue.location

	@location.setter
	def location(self, value):
		self.venue.location = value

class Venue(object):
	def __init__(self, address, latitude=None, longitude=None, url=None, description=None):
		self.location = {
			"address": address,
			"latitude": latitude,
			"longitude": longitude
		}
		self.url = url
		self.description = description
