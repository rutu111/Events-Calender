from abc import ABC, abstractmethod

class DispatcherEvent(ABC):
	# add some abstract methods here when needed.
	pass

class CrawlerDiscoveredCalendarEventEvent(DispatcherEvent): # For each calendar event the crawler finds on its crawl (potentially mostly duplicates)
	def __init__(self, event):
		self.event = event

class DiscoveredRecommendationEvent(DispatcherEvent):
	def __init__(self, recommendation):
		self.recommendation = recommendation

class NewCalendarEventEvent(DispatcherEvent):
	def __init__(self, event):
		self.event = event

class UserEvent(DispatcherEvent):
	def __init__(self, user):
		self.user = user

class UserLoginEvent(UserEvent):
	def __init__(self, user, token):
		super().__init__(user)
		self.token = token

class UserFeedbackEvent(UserEvent):
	def __init__(self, user, feedback):
		super().__init__(user)
		self.feedback = feedback

class NewUserEvent(UserEvent):
	pass

class SystemStartEvent(DispatcherEvent):
	pass
