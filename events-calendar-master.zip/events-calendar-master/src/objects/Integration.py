from abc import ABC, abstractmethod
from requests_oauthlib import OAuth2Session

try:
	from settings import OAUTH_REDIRECT_URI as redirectUri
except ImportError as e:
	raise ImportError("Unable to load integrations data from settings; are you sure you set it up correctly?") from e

class LoginURL():
	def __init__(self, url, state):
		self.url = url
		self.state = state

class Integration(ABC):
	def login(self, code):
		token = self.getSession().fetch_token(self.getTokenURL(), code=code, client_secret=self.getClientSecret()) # attempts to redeem `code` with the integration (eg facebook) for a token
		return self.getUserDetails(token) # attempts to use the new token to get user information from the integration

	def getSession(self, token=None):
		if token is None:
			return OAuth2Session(self.getClientId(), redirect_uri=redirectUri) # returns an OAuth session that can be used to login to an integration
		return OAuth2Session(self.getClientId(), token=token, redirect_uri=redirectUri) # returns an OAuth session that can be used to queury the api of an integration using the scope of `token`

	def getAuthURL(self, scope=None):
		(url, state) = self.getSession().authorization_url(self.getBaseAuthURL()) # uses an OAuth session and the config settings to generate a login URL
		return LoginURL(url, state)

	@abstractmethod
	def getClientId(self):
		pass

	@abstractmethod
	def getClientSecret(self):
		pass

	@abstractmethod
	def getTokenURL(self):
		pass

	@abstractmethod
	def getBaseAuthURL(self):
		pass

	@abstractmethod
	def getUserDetails(self, token):
		pass
