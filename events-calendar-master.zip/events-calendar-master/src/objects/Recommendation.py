class Recommendation(object):
	def __init__(self, user, event, weight):
		self.user = user
		self.event = event
		self.weight = weight

class Feedback(object):
	def __init__(self, user, event, rating):
		self.user = user
		self.event = event
		self.rating = rating
