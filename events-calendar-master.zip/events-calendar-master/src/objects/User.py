class User(object):
	def __init__(self, name, integration, integrationId, token=None):
		self.name = name
		self.integration = integration
		self.integrationId = integrationId
		self.token = token
		self.categories = {}
