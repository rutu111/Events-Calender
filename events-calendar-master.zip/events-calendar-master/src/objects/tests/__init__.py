from objects.Integration import Integration
from objects.User import User

# a dummy implementation of Integration for use in tests
class EmptyIntegration(Integration):
	def getClientId(self):
		return "123456"

	def getClientSecret(self):
		return "abcdef"

	def getTokenURL(self):
		return "https://token.com"

	def getBaseAuthURL(self):
		return "https://auth.com"

	def getUserDetails(self, token):
		return User("user", self, token)
