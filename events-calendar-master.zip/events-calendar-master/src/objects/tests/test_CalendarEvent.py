import unittest
from datetime import datetime

from objects.User import User
from objects.CalendarEvent import CalendarEvent, CalendarEventRun, Venue

from . import EmptyIntegration

class TestCalendarEventRun(unittest.TestCase):
	def setUp(self):
		self.user = User("user", EmptyIntegration(), "123456")
		self.event = CalendarEvent("title", "description", "example.com", "category", owner=self.user, thumbnail="thumb", image="image")
		self.venue = Venue("somewhere near the equator", latitude=10, longitude=20, url="ven.ue", description="a lovely place")
		self.startDate = datetime(2018, 2, 10)
		self.endDate = datetime(2018, 2, 11)
		self.eventID = "This is a test ID, it can be whatever"
		self.run = CalendarEventRun(self.eventID, self.event, self.startDate, self.endDate, self.venue)

	def tearDown(self):
		pass

	def test_properties(self):
		# test that all the values have been initialised
		self.assertEqual(self.run.id, self.eventID)
		self.assertEqual(self.run.start, self.startDate)
		self.assertEqual(self.run.end, self.endDate)
		self.assertEqual(self.run.venue, self.venue)

		# test that the base event can be obtained
		self.assertEqual(self.run.getBase(), self.event)

		# test that getters are working correctly
		self.assertEqual(self.run.title, self.event.title)
		self.assertEqual(self.run.description, self.event.description)
		self.assertEqual(self.run.url, self.event.url)
		self.assertEqual(self.run.category, self.event.category)
		self.assertEqual(self.run.owner, self.event.owner)
		self.assertEqual(self.run.thumbnail, self.event.thumbnail)
		self.assertEqual(self.run.image, self.event.image)

		self.assertEqual(self.run.location, self.venue.location)

		# test that setters are working correctly
		self.run.title = "new title"
		self.assertEqual(self.event.title, "new title")
		self.run.description = "new description"
		self.assertEqual(self.event.description, "new description")
		self.run.url = "new url"
		self.assertEqual(self.event.url, "new url")
		self.run.category = "new category"
		self.assertEqual(self.event.category, "new category")
		self.run.owner = None
		self.assertEqual(self.event.owner, None)
		self.run.thumbnail = "new thumbnail"
		self.assertEqual(self.event.thumbnail, "new thumbnail")
		self.run.image = "new image"
		self.assertEqual(self.event.image, "new image")

		location = self.run.location = {
			"latitude": 5,
			"longitude": 10
		}
		self.assertEqual(self.venue.location, location)

class TestCalendarEvent(unittest.TestCase):
	def setUp(self):
		# create objects
		self.user = User("user", EmptyIntegration(), "123456")
		self.event = CalendarEvent("title", "description", "example.com", "category", owner=self.user, thumbnail="thumb", image="image")

	def tearDown(self):
		pass

	def test_properties(self):
		# test that all the values have been initialised
		self.assertEqual(self.event.title, "title")
		self.assertEqual(self.event.description, "description")
		self.assertEqual(self.event.url, "example.com")
		self.assertEqual(self.event.category, "category")
		self.assertEqual(self.event.owner, self.user)
		self.assertEqual(self.event.thumbnail, "thumb")
		self.assertEqual(self.event.image, "image")

	def test_methodProperties(self):
		# test if the isUserCreated method works correctly.
		self.assertTrue(self.event.isUserCreated)
		self.event.owner = None
		self.assertFalse(self.event.isUserCreated)

class TestVenue(unittest.TestCase):
	def setUp(self):
		# create objects
		self.venue = Venue("somewhere near the equator", latitude=10, longitude=20, url="ven.ue", description="a lovely place")

	def tearDown(self):
		pass

	def test_properties(self):
		# to check that all the values have been initialised
		self.assertIsInstance(self.venue.location, dict)
		self.assertEqual(self.venue.location["latitude"], 10)
		self.assertEqual(self.venue.location["longitude"], 20)
		self.assertEqual(self.venue.location["address"], "somewhere near the equator")
		self.assertEqual(self.venue.url, "ven.ue")
		self.assertEqual(self.venue.description, "a lovely place")

