import unittest

from objects.DispatcherEvent import DispatcherEvent, CrawlerDiscoveredCalendarEventEvent, DiscoveredRecommendationEvent, NewCalendarEventEvent, UserEvent, UserLoginEvent, UserFeedbackEvent, NewUserEvent
from objects.CalendarEvent import CalendarEvent
from objects.User import User
from objects.Recommendation import Recommendation

from . import EmptyIntegration

class TestCrawlerDiscoveredCalendarEventEvent(unittest.TestCase):
	def setUp(self):
		self.event = CalendarEvent("title", "description", "example.com", "category")
		self.dispatcherEvent = CrawlerDiscoveredCalendarEventEvent(self.event)

	def tearDown(self):
		pass

	def test_is_dispatcher_event(self):
		self.assertTrue(issubclass(CrawlerDiscoveredCalendarEventEvent, DispatcherEvent))

	def test_properties(self):
		self.assertEqual(self.dispatcherEvent.event, self.event)

class TestDiscoveredRecommendationEvent(unittest.TestCase):
	def setUp(self):
		self.recommendation = Recommendation(None, None, 0)
		self.dispatcherEvent = DiscoveredRecommendationEvent(self.recommendation)

	def tearDown(self):
		pass

	def test_is_dispatcher_event(self):
		self.assertTrue(issubclass(DiscoveredRecommendationEvent, DispatcherEvent))

	def test_properties(self):
		self.assertEqual(self.dispatcherEvent.recommendation, self.recommendation)

class TestNewCalendarEventEvent(unittest.TestCase):
	def setUp(self):
		self.event = CalendarEvent("title", "description", "example.com", "category")
		self.dispatcherEvent = NewCalendarEventEvent(self.event)

	def tearDown(self):
		pass

	def test_is_dispatcher_event(self):
		self.assertTrue(issubclass(NewCalendarEventEvent, DispatcherEvent))

	def test_properties(self):
		self.assertEqual(self.dispatcherEvent.event, self.event)

class TestUserEvent(unittest.TestCase):
	def setUp(self):
		self.user = User("user", EmptyIntegration(), "123456")
		self.dispatcherEvent = UserEvent(self.user)

	def tearDown(self):
		pass

	def test_is_dispatcher_event(self):
		self.assertTrue(issubclass(UserEvent, DispatcherEvent))

	def test_properties(self):
		self.assertEqual(self.dispatcherEvent.user, self.user)

class TestUserLoginEvent(unittest.TestCase):
	def setUp(self):
		self.user = User("user", EmptyIntegration(), "123456")
		self.token = "abcdef"
		self.dispatcherEvent = UserLoginEvent(self.user, self.token)

	def tearDown(self):
		pass

	def test_is_user_event(self):
		self.assertTrue(issubclass(UserLoginEvent, UserEvent))

	def test_properties(self):
		self.assertEqual(self.dispatcherEvent.user, self.user)
		self.assertEqual(self.dispatcherEvent.token, self.token)

class TestUserFeedbackEvent(unittest.TestCase):
	def setUp(self):
		self.user = User("user", EmptyIntegration(), "123456")
		self.feedback = {}
		self.dispatcherEvent = UserFeedbackEvent(self.user, self.feedback)

	def tearDown(self):
		pass

	def test_is_user_event(self):
		self.assertTrue(issubclass(UserFeedbackEvent, UserEvent))

	def test_properties(self):
		self.assertEqual(self.dispatcherEvent.user, self.user)
		self.assertEqual(self.dispatcherEvent.feedback, self.feedback)

class TestNewUserEvent(unittest.TestCase):
	def setUp(self):
		self.user = User("user", EmptyIntegration(), "123456")
		self.dispatcherEvent = NewUserEvent(self.user)

	def tearDown(self):
		pass

	def test_is_user_event(self):
		self.assertTrue(issubclass(NewUserEvent, UserEvent))

	def test_properties(self):
		self.assertEqual(self.dispatcherEvent.user, self.user)

