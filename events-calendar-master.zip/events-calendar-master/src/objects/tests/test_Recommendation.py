import unittest

from objects.CalendarEvent import CalendarEvent
from objects.User import User
from objects.Recommendation import Recommendation, Feedback

from . import EmptyIntegration

class TestRecommendation(unittest.TestCase):
	def setUp(self):
		# create objects
		self.user = User("user", EmptyIntegration(), "123456")
		self.event = CalendarEvent("title", "description", "example.com", "category")
		self.recommendation = Recommendation(self.user, self.event, 15.0) #creating recommendation object using objects above

	def tearDown(self):
		pass

	def test_properties(self):
		# to check that all the values have been initialised
		self.assertEqual(self.recommendation.user, self.user)
		self.assertEqual(self.recommendation.event, self.event)
		self.assertEqual(self.recommendation.weight, 15.0)

# TODO test feedback
