import unittest

from objects.User import User

from . import EmptyIntegration

class TestUserObject(unittest.TestCase):
	def setUp(self):
		# create objects
		self.integration = EmptyIntegration()
		self.user = User("username1", self.integration, 123456, token="123456")

	def tearDown(self):
		pass

	def test_properties(self):
		# to check that all the values have been initialised
		self.assertEqual(self.user.name, "username1")
		self.assertEqual(self.user.integration, self.integration)
		self.assertEqual(self.user.integrationId, 123456)
		self.assertEqual(self.user.token, "123456")
