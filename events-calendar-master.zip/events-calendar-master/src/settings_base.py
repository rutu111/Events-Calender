"""
Project settings

YOU SHOULD NOT EDIT THIS FILE.
It is required that you create a file settings.py in which you define at least the following values:

INTEGRATIONS = {
	'facebook': {
		'id':	 '<Facebook App ID>',
		'secret': '<Facebook App secret>'
	}
}
OAUTH_REDIRECT_URI = "http://example-domain.com/login"

DATABASE = {
	'hostname': 'localhost',
	'port':     3306,
	'username': 'root',
	'password': '<password>',
	'database': 'events_calendar',
	'charset':  'utf8mb4',
}

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "<password>"

You are also strongly advised to set SECRET_KEY to some hidden value to keep users from modifying session data and bypassing security.

You may however override any values here and any other values found in the lists below in settings.py

For the full list of settings and their values for Django, see
https://docs.djangoproject.com/en/2.0/ref/settings/
For the full list of settings and their values for Scrapy, see
https://doc.scrapy.org/en/latest/topics/settings.html#built-in-settings-reference

The following options are built into the system and are not documented externally:
DISABLE_CACHE = True
DEBUG_LOGIN = True
"""

import os

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/2.0/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = ''

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

ALLOWED_HOSTS = []


# Application definition

INSTALLED_APPS = [
	'django.contrib.contenttypes',
	'django.contrib.auth',
	'django.contrib.messages',
	'django.contrib.staticfiles'
]

MIDDLEWARE = [
	'django.middleware.security.SecurityMiddleware',
	'django.contrib.sessions.middleware.SessionMiddleware',
	'django.middleware.common.CommonMiddleware',
	'django.middleware.csrf.CsrfViewMiddleware',
	'django.contrib.auth.middleware.AuthenticationMiddleware',
	'django.contrib.messages.middleware.MessageMiddleware',
	'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

SESSION_ENGINE = "django.contrib.sessions.backends.signed_cookies"
SESSION_COOKIE_HTTPONLY = True

ROOT_URLCONF = 'web.urls'

TEMPLATES = [
	{
		'BACKEND': 'django.template.backends.django.DjangoTemplates',
		'DIRS': [os.path.join(BASE_DIR, 'web/dynamic/') + d for d in ['css', 'js', 'image', 'html']],
		'APP_DIRS': True,
		'OPTIONS': {
			'context_processors': [
				'django.template.context_processors.debug',
				'django.template.context_processors.request',
				'django.contrib.auth.context_processors.auth',
				'django.contrib.messages.context_processors.messages',
			],
		},
	},
]

WSGI_APPLICATION = 'wsgi.application'


# Database
# https://docs.djangoproject.com/en/2.0/ref/settings/#databases

DATABASES = {}


# Password validation
# https://docs.djangoproject.com/en/2.0/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
	{
		'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
	},
	{
		'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
	},
	{
		'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
	},
	{
		'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
	},
]

# Internationalization
# https://docs.djangoproject.com/en/2.0/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/2.0/howto/static-files/

STATIC_URL = '/static/'
STATICFILES_DIRS = [
	os.path.join(BASE_DIR, 'web/static/')
]

#Crawler stuff
BOT_NAME = 'events-calendar-crawler'
SPIDER_MODULES = ['logic.crawler']
NEWSPIDER_MODULE = ''
ROBOTSTXT_OBEY = True
ITEM_PIPELINES = {
	'logic.crawler.AusacrawlerPipeline': 1,
	'logic.crawler.FacebookcrawlerPipeline': 2
}
SPIDER_MIDDLEWARES = {}
DOWNLOADER_MIDDLEWARES = {}
LOG_LEVEL = "WARNING"

#Debug options
DISABLE_CACHE = False
DEBUG_LOGIN = False

from settings import *
