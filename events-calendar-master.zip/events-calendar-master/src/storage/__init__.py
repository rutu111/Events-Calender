from threading import RLock

import pymysql.cursors
import settings_base as settings

from objects.CalendarEvent import CalendarEvent, CalendarEventRun, Venue
from objects.Recommendation import Recommendation, Feedback
from objects.User import User

def mysql():
	return pymysql.connect(
		host        = settings.DATABASE['hostname'],
		port        = (int) (settings.DATABASE['port']),
		user        = settings.DATABASE['username'],
		password    = settings.DATABASE['password'],
		db          = settings.DATABASE['database'],
		charset     = settings.DATABASE['charset'],
		cursorclass = pymysql.cursors.DictCursor
	)

# a decorator for locking objects
def locks(*args):
	def wrappedLocks(fn):
		def wrappedFunction(*args2):
			with lock(*args):
				return fn(*args2)
		return wrappedFunction
	return wrappedLocks


class lock(object):
	# as a general rule, these should be ordered from least to most frequently accessed.
	OBJECTS = [
		Feedback,
		Venue,
		CalendarEventRun,
		Recommendation,
		CalendarEvent,
		User
	]
	LOCKS = {o: RLock() for o in OBJECTS}

	def __init__(self, *args):
		self.objects = sorted([a for a in args if a in self.__class__.OBJECTS], key=self.__class__.OBJECTS.index)
		self.locked = False

	def acquire(self):
		self.__enter__()

	def release(self):
		self.__exit__(None, None, None)

	def __enter__(self):
		if self.locked:
			raise Exception("Already locked")
		self.locked = True
		for o in self.objects:
			self.__class__.LOCKS[o].acquire()

	def __exit__(self, exceptionType, exception, trace):
		if not self.locked:
			return
		self.locked = False
		for o in self.objects:
			self.__class__.LOCKS[o].release()
