import weakref
from threading import Lock

try:
	from settings_base import DISABLE_CACHE
except ImportError:
	DISABLE_CACHE = False

_LOCK = Lock() # used to ensure that no thread gets out-of-sync data from _CACHE
_CACHE = {}

def _delete(key):
	with _LOCK:
		value = _CACHE[key]
		del _CACHE[value]
		del _CACHE[key]

def _isKey(key):
	return isinstance(key, (int, str))

def get(key):
	if DISABLE_CACHE:
		return None
	if key is None:
		return None
	if not _isKey(key) and not isinstance(key, weakref.ReferenceType):
		key = weakref.ref(key)
	with _LOCK:
		value = _CACHE.get(key)
	if isinstance(value, weakref.ReferenceType):
		return value()
	return value

def associateKeys(keyList):
	return {key: get(key) for key in keyList if get(key) is not None}

def associateValues(valueList):
	return {get(value): value for value in valueList if get(value) is not None}

def put(key, value):
	if DISABLE_CACHE:
		return
	ref = weakref.ref(value, _delete)
	with _LOCK:
		if _CACHE.get(key) is not None or _CACHE.get(value) is not None:
			if isinstance(_CACHE.get(key), weakref.ReferenceType):
				print("Weakref died without being collected", _CACHE.get(key))
			raise KeyError("Duplicate item insertion in cache: check that item isn't already stored before insertion of", key, value)
		_CACHE[key] = ref
		_CACHE[ref] = key # allow lookup of key from value. Collisions should be avoidable by using complex objects for values and simple ones for keys.
