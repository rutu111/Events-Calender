from objects.CalendarEvent import CalendarEvent, CalendarEventRun, Venue
from objects.User import User

from storage.users import getUser, getAllUsers
from storage import cache

from . import mysql, locks

def getAllCategories():
	with mysql() as cursor:
		cursor.execute("""SELECT category FROM categories""")

		results = cursor.fetchall()

		return [result["category"] for result in results]


@locks(CalendarEvent)
def getCalendarEvent(eventID):
	if eventID is None:
		return None
	cachedEvent = cache.get(eventID)
	if cachedEvent:
		return cachedEvent if isinstance(cachedEvent, CalendarEvent) else None

	with mysql() as cursor:
		cursor.execute("""SELECT id as id, title, url, description, category as category, owner, thumbnail, image
		                  FROM events
		                  WHERE id = %s""", (str(eventID)))

		result = cursor.fetchone()
		if result is None:
			return None

		owner = getUser(result["owner"])

		event = CalendarEvent(result["title"], result["description"], result["url"], result["category"], owner, result["thumbnail"], result["image"])

		cache.put(result["id"], event)

		return event

@locks(CalendarEvent)
def getAllCalendarEvents():
	with mysql() as cursor:
		cursor.execute("""SELECT id as id, title, url, description, category as category, owner, thumbnail, image
		                  FROM events""")

		assoc = cache.associateValues(getAllUsers())

		allEvents = []
		for result in cursor.fetchall():
			cachedEvent = cache.get(result["id"])
			if cachedEvent:
				allEvents.append(cachedEvent)
				continue

			owner = assoc.get(result["owner"]) or getUser(result["owner"])

			event = CalendarEvent(result["title"], result["description"], result["url"], result["category"], owner, result["thumbnail"], result["image"])

			cache.put(result["id"], event)

			allEvents.append(event)
		return allEvents

@locks(CalendarEvent, User)
def storeCalendarEvent(event):
	if cache.get(event) is not None:
		raise ValueError("Object passed cannot be stored as it already exists in the system")

	ownerID = cache.get(event.owner)

	with mysql() as cursor:
		cursor.execute("""INSERT INTO events(title, url, description, category, owner, thumbnail, image)
		                 VALUES(%s, %s, %s, %s, %s, %s, %s)""", (event.title, event.url, event.description, event.category, ownerID, event.thumbnail, event.image))
		cursor.execute("""SELECT @last_uuid as id""")
		eventID = cursor.fetchone()["id"]
		cache.put(eventID, event)

@locks(CalendarEvent, User)
def updateCalendarEvent(event):
	eventID = cache.get(event)
	if eventID is None:
		raise ValueError("Object passed cannot be updated as it doesn't in the system")

	ownerID = cache.get(event.owner)

	with mysql() as cursor:
		cursor.execute("""UPDATE events
		                 SET title = %s, url = %s, description = %s, category = %s, owner = %s, thumbnail = %s, image = %s
		                 WHERE id = %s""", (event.title, event.url, event.description, event.category, ownerID, event.thumbnail, event.image, eventID))

@locks(CalendarEvent, User)
def deleteCalendarEvent(event):
	eventID = cache.get(event)
	if eventID is None:
		raise ValueError("Object passed cannot be deleted as it doesn't in the system")

	with mysql() as cursor:
		cursor.execute("""DELETE events
		                 FROM events
		                 WHERE events.id=%s""", (eventID))

@locks(Venue)
def getVenue(venueID):
	if venueID is None:
		return None
	cachedVenue = cache.get(venueID)
	if cachedVenue:
		return cachedVenue if isinstance(cachedVenue, Venue) else None

	with mysql() as cursor:
		cursor.execute("""SELECT id, address, latitude, longitude, url, description
		                  FROM venues
		                  WHERE id = %s""", (str(venueID)))

		result = cursor.fetchone()
		if result is None:
			return None

		venue = Venue(result["address"], result["latitude"], result["longitude"], result["url"], result["description"])

		cache.put(result["id"], venue)

		return venue

@locks(Venue)
def getAllVenues():
	with mysql() as cursor:
		cursor.execute("""SELECT id, address, latitude, longitude, url, description
		                  FROM venues""")

		allVenues = []
		for result in cursor.fetchall():
			cachedVenue = cache.get(result["id"])
			if cachedVenue:
				allVenues.append(cachedVenue)
				continue

			venue = Venue(result["address"], result["latitude"], result["longitude"], result["url"], result["description"])

			cache.put(result["id"], venue)

			allVenues.append(venue)
		return allVenues

@locks(Venue)
def storeVenue(venue):
	if cache.get(venue) is not None:
		raise ValueError("Object passed cannot be stored as it already exists in the system")

	with mysql() as cursor:
		cursor.execute("""INSERT INTO venues(address, latitude, longitude, url, description)
		                 VALUES(%s, %s, %s, %s, %s)""", (venue.location["address"], venue.location["latitude"], venue.location["longitude"], venue.url, venue.description))
		cursor.execute("""SELECT @last_uuid as id""")
		venueID = cursor.fetchone()["id"]
		cache.put(venueID, venue)

@locks(Venue)
def updateVenue(venue):
	venueID = cache.get(venue)
	if venueID is None:
		raise ValueError("Object passed cannot be updated as it doesn't in the system")

	with mysql() as cursor:
		cursor.execute("""UPDATE venues
		                 SET address = %s, latitude = %s, longitude = %s, url = %s, description = %s
		                 WHERE id = %s""", (venue.location["address"], venue.location["latitude"], venue.location["longitude"], venue.url, venue.description, venueID))

@locks(CalendarEventRun)
def getCalendarEventRun(eventRunID):
	if eventRunID is None:
		return None
	cachedEventRun = cache.get(eventRunID)
	if cachedEventRun:
		return cachedEventRun if isinstance(cachedEventRun, CalendarEventRun) else None

	with mysql() as cursor:
		cursor.execute("""SELECT id, event, start_date, end_date, venue, cancelled, fully_booked
		                  FROM event_runs
		                  WHERE id = %s""", (str(eventRunID)))

		result = cursor.fetchone()
		if result is None:
			return None

		event = getCalendarEvent(result["event"])
		if event is None:
			print("WARNING: missing foreign object CalendarEvent (%s) for CalendarEventRun (%s)" % (result["event"], result["id"]))
			return None

		venue = getVenue(result["venue"])
		if venue is None:
			print("WARNING: missing foreign object Venue (%s) for CalendarEvent (%s)" % (result["venue"], result["id"]))
			return None

		eventRun = CalendarEventRun(result["id"], event, result["start_date"], result["end_date"], venue)
		eventRun.cancelled = result["cancelled"]
		eventRun.fullyBooked = result["fully_booked"]

		cache.put(result["id"], eventRun)

		return eventRun

@locks(CalendarEventRun)
def getAllCalendarEventRuns():
	with mysql() as cursor:
		cursor.execute("""SELECT id, event, start_date, end_date, venue, cancelled, fully_booked
		                  FROM event_runs""")

		assocEvents = cache.associateValues(getAllCalendarEvents())
		assocVenues = cache.associateValues(getAllVenues())

		allEventRuns = []
		for result in cursor.fetchall():
			cachedEventRun = cache.get(result["id"])
			if cachedEventRun:
				allEventRuns.append(cachedEventRun)
				continue

			event = assocEvents.get(result["event"]) or getCalendarEvent(result["event"])
			if event is None:
				print("WARNING: missing foreign object CalendarEvent (%s) for CalendarEventRun (%s)" % (result["event"], result["id"]))
				continue

			venue = assocVenues.get(result["venue"]) or getVenue(result["venue"])
			if venue is None:
				print("WARNING: missing foreign object Venue (%s) for CalendarEvent (%s)" % (result["venue"], result["id"]))
				continue

			eventRun = CalendarEventRun(result["id"], event, result["start_date"], result["end_date"], venue)
			eventRun.cancelled = result["cancelled"]
			eventRun.fullyBooked = result["fully_booked"]

			cache.put(result["id"], eventRun)

			allEventRuns.append(eventRun)
		return allEventRuns

@locks(CalendarEventRun, CalendarEvent, Venue)
def storeCalendarEventRun(eventRun):
	if cache.get(eventRun) is not None:
		raise ValueError("Object passed cannot be stored as it already exists in the system")

	eventID = cache.get(eventRun.getBase())
	if eventID is None:
		raise ValueError("Object depends on an event object that is not stored in the system")

	venueID = cache.get(eventRun.venue)
	if venueID is None:
		for result in getAllVenues():
			if result.location["address"] == eventRun.venue.location["address"]:
				venueID = cache.get(result)
				break
	if venueID is None:
		raise ValueError("Object depends on an venue object that is not stored in the system")

	with mysql() as cursor:
		cursor.execute("""INSERT INTO event_runs(event, start_date, end_date, venue, cancelled, fully_booked)
		                 VALUES(%s, %s, %s, %s, %s, %s)""", (eventID, eventRun.start, eventRun.end, venueID, eventRun.cancelled, eventRun.fullyBooked))
		cursor.execute("""SELECT @last_uuid as id""")
		eventRunID = cursor.fetchone()["id"]
		cache.put(eventRunID, eventRun)

@locks(CalendarEventRun, CalendarEvent, Venue)
def updateCalendarEventRun(eventRun):
	eventRunID = cache.get(eventRun)
	if eventRunID is None:
		raise ValueError("Object passed cannot be updated as it doesn't in the system")

	eventID = cache.get(eventRun.getBase())
	if eventID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	venueID = cache.get(eventRun.venue)
	if venueID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	with mysql() as cursor:
		cursor.execute("""UPDATE event_runs
		                 SET event = %s, start_date = %s, end_date = %s, venue = %s, cancelled = %s, fully_booked = %s
		                 WHERE id = %s""", (eventID, eventRun.start, eventRun.end, venueID, eventRun.cancelled, eventRun.fullyBooked, eventRunID))

@locks(CalendarEvent, User)
def deleteCalendarEventRun(eventRun):
	eventRunID = cache.get(eventRun)
	if eventRunID is None:
		raise ValueError("Object passed cannot be deleted as it doesn't in the system")

	with mysql() as cursor:
		cursor.execute("""DELETE event_runs
		                 FROM event_runs
		                 WHERE event_runs.id=%s""", (eventRunID))

def getPopularEvents():
	with mysql() as cursor:
		cursor.execute("""SELECT event_runs.id as id, event_runs.event as event, start_date, end_date, venue, cancelled, fully_booked
		                  FROM event_runs
						  LEFT JOIN feedback ON event_runs.id=feedback.event
						  GROUP BY event_runs.id
						  ORDER BY SUM(RATING) - COUNT(RATING) + SUM(RATING) DESC,
						  end_date ASC""")

		assocEvents = cache.associateValues(getAllCalendarEvents())
		assocVenues = cache.associateValues(getAllVenues())

		allEventRuns = []
		for result in cursor.fetchall():
			cachedEventRun = cache.get(result["id"])
			if cachedEventRun:
				allEventRuns.append(cachedEventRun)
				continue

			event = assocEvents.get(result["event"]) or getCalendarEvent(result["event"])
			if event is None:
				print("WARNING: missing foreign object CalendarEvent (%s) for CalendarEventRun (%s)" % (result["event"], result["id"]))
				continue

			venue = assocVenues.get(result["venue"]) or getVenue(result["venue"])
			if venue is None:
				print("WARNING: missing foreign object Venue (%s) for CalendarEvent (%s)" % (result["venue"], result["id"]))
				continue

			eventRun = CalendarEventRun(result["id"], event, result["start_date"], result["end_date"], venue)
			eventRun.cancelled = result["cancelled"]
			eventRun.fullyBooked = result["fully_booked"]

			cache.put(result["id"], eventRun)

			allEventRuns.append(eventRun)
		return allEventRuns
