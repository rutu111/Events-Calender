from objects.Recommendation import Recommendation, Feedback

from storage.users import getUser, getAllUsers
from storage.events import getCalendarEvent, getAllCalendarEvents, getCalendarEventRun, getAllCalendarEventRuns
from storage import cache

from . import mysql, locks

@locks(Recommendation)
def getRecommendation(recommendationID):
	if recommendationID is None:
		return None
	cachedRecommendation = cache.get(recommendationID)
	if cachedRecommendation:
		return cachedRecommendation if isinstance(cachedRecommendation, Recommendation) else None

	with mysql() as cursor:
		cursor.execute("""SELECT id, user, event, weight
		                  FROM recommendations
		                  WHERE id = %s""", (str(recommendationID)))

		result = cursor.fetchone()
		if result is None:
			return None

		user = getUser(result["user"])
		if user is None:
			print("WARNING: missing foreign object User (%s) for Recommendation (%s)" % (result["user"], result["id"]))
			return None

		event = getCalendarEvent(result["event"])
		if event is None:
			print("WARNING: missing foreign object Event (%s) for Recommendation (%s)" % (result["event"], result["id"]))
			return None

		recommendation = Recommendation(user, event, result["weight"])

		cache.put(result["id"], recommendation)

		return recommendation

@locks(Recommendation)
def getAllRecommendationsForUser(user):
	userID = cache.get(user)
	if userID is None:
		return []
	with mysql() as cursor:
		cursor.execute("""SELECT id, user, event, weight
		                  FROM recommendations
		                  WHERE user = %s""", (userID))

		assocEvents = cache.associateValues(getAllCalendarEvents())
		assocUsers = cache.associateValues(getAllUsers())

		allUsers = []
		for result in cursor.fetchall():
			cachedRecommendation = cache.get(result["id"])
			if cachedRecommendation:
				allUsers.append(cachedRecommendation)
				continue

			user = assocUsers.get(result["user"]) or getUser(result["user"])
			if user is None:
				print("WARNING: missing foreign object User (%s) for Recommendation (%s)" % (result["user"], result["id"]))
				continue

			event = assocEvents.get(result["event"]) or getCalendarEvent(result["event"])
			if event is None:
				print("WARNING: missing foreign object CalendarEvent (%s) for Recommendation (%s)" % (result["event"], result["id"]))
				continue

			recommendation = Recommendation(user, event, result["weight"])

			cache.put(result["id"], recommendation)

			allUsers.append(recommendation)
		return allUsers

@locks(Recommendation)
def getAllRecommendations():
	with mysql() as cursor:
		cursor.execute("""SELECT id, user, event, weight
		                  FROM recommendations""")

		assocEvents = cache.associateValues(getAllCalendarEvents())
		assocUsers = cache.associateValues(getAllUsers())

		allUsers = []
		for result in cursor.fetchall():
			cachedRecommendation = cache.get(result["id"])
			if cachedRecommendation:
				allUsers.append(cachedRecommendation)
				continue

			user = assocUsers.get(result["user"]) or getUser(result["user"])
			if user is None:
				print("WARNING: missing foreign object User (%s) for Recommendation (%s)" % (result["user"], result["id"]))
				continue

			event = assocEvents.get(result["event"]) or getCalendarEvent(result["event"])
			if event is None:
				print("WARNING: missing foreign object CalendarEvent (%s) for Recommendation (%s)" % (result["event"], result["id"]))
				continue

			recommendation = Recommendation(user, event, result["weight"])

			cache.put(result["id"], recommendation)

			allUsers.append(recommendation)
		return allUsers

@locks(Recommendation)
def storeRecommendation(recommendation):
	if cache.get(recommendation) is not None:
		raise ValueError("Object passed cannot be stored as it already exists in the system")

	userID = cache.get(recommendation.user)
	if userID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	eventID = cache.get(recommendation.event)
	if eventID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	with mysql() as cursor:
		cursor.execute("""INSERT INTO recommendations(user, event, weight)
		                  VALUES(%s, %s, %s)""", (userID, eventID, recommendation.weight))
		cursor.execute("""SELECT @last_uuid as id""")
		recommendationID = cursor.fetchone()["id"]
		cache.put(recommendationID, recommendation)

@locks(Recommendation)
def updateRecommendation(recommendation):
	recommendationID = cache.get(recommendation)
	if recommendationID is None:
		raise ValueError("Object passed cannot be updated as it doesn't in the system")

	userID = cache.get(recommendation.user)
	if userID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	eventID = cache.get(recommendation.event)
	if eventID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	with mysql() as cursor:
		cursor.execute("""UPDATE recommendations
		                  SET user = %s, event = %s, weight = %s
		                  WHERE id = %s""", (userID, eventID, recommendation.weight, recommendationID))

@locks(Recommendation)
def deleteRecommendation(recommendation):
	recommendationID = cache.get(recommendation)
	if recommendationID is None:
		raise ValueError("Object passed cannot be deleted as it doesn't in the system")

	with mysql() as cursor:
		cursor.execute("""DELETE recommendations
		                 FROM recommendations
		                 WHERE recommendations.id=%s""", (recommendationID))

@locks(Feedback)
def getFeedback(feedbackID):
	if feedbackID is None:
		return None
	cachedFeedback = cache.get(feedbackID)
	if cachedFeedback:
		return cachedFeedback if isinstance(cachedFeedback, Feedback) else None

	with mysql() as cursor:
		cursor.execute("""SELECT id, user, event, rating
		                  FROM feedback
		                  WHERE id = %s""", (str(feedbackID)))

		result = cursor.fetchone()
		if result is None:
			return None

		user = getUser(result["user"])
		if user is None:
			print("WARNING: missing foreign object User (%s) for Feedback (%s)" % (result["user"], result["id"]))
			return None

		event = getCalendarEventRun(result["event"])
		if event is None:
			print("WARNING: missing foreign object Event (%s) for Feedback (%s)" % (result["event"], result["id"]))
			return None

		feedback = Feedback(user, event, result["rating"])

		cache.put(result["id"], feedback)

		return feedback

@locks(Feedback)
def getFeedbackForUserAndEvent(user, event):
	if user is None or event is None:
		return None

	userID = cache.get(user)
	eventID = cache.get(event)
	if userID is None or eventID is None:
		return None

	with mysql() as cursor:
		cursor.execute("""SELECT id, user, event, rating
		                  FROM feedback
		                  WHERE user = %s AND event = %s""", (userID, eventID))

		result = cursor.fetchone()

		if result is None:
			return None

		cachedFeedback = cache.get(result["id"])
		if cachedFeedback:
			return cachedFeedback if isinstance(cachedFeedback, Feedback) else None

		feedback = Feedback(user, event, result["rating"])

		cache.put(result["id"], feedback)

		return feedback

@locks(Feedback)
def getAllFeedback():
	with mysql() as cursor:
		cursor.execute("""SELECT id, user, event, rating
		                  FROM feedback""")

		assocEvents = cache.associateValues(getAllCalendarEventRuns())
		assocUsers = cache.associateValues(getAllUsers())

		allUsers = []
		for result in cursor.fetchall():
			cachedFeedback = cache.get(result["id"])
			if cachedFeedback:
				allUsers.append(cachedFeedback)
				continue

			user = assocUsers.get(result["user"]) or getUser(result["user"])
			if user is None:
				print("WARNING: missing foreign object User (%s) for Feedback (%s)" % (result["user"], result["id"]))
				continue

			event = assocEvents.get(result["event"]) or getCalendarEventRun(result["event"])
			if event is None:
				print("WARNING: missing foreign object CalendarEvent (%s) for Feedback (%s)" % (result["event"], result["id"]))
				continue

			feedback = Feedback(user, event, result["rating"])

			cache.put(result["id"], feedback)

			allUsers.append(feedback)
		return allUsers

@locks(Feedback)
def storeFeedback(feedback):
	if cache.get(feedback) is not None:
		raise ValueError("Object passed cannot be stored as it already exists in the system")

	userID = cache.get(feedback.user)
	if userID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	eventID = cache.get(feedback.event)
	if eventID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	with mysql() as cursor:
		cursor.execute("""INSERT INTO feedback(user, event, rating)
		                  VALUES(%s, %s, %s)""", (userID, eventID, feedback.rating))
		cursor.execute("""SELECT @last_uuid as id""")
		feedbackID = cursor.fetchone()["id"]
		cache.put(feedbackID, feedback)

@locks(Feedback)
def updateFeedback(feedback):
	feedbackID = cache.get(feedback)
	if feedbackID is None:
		raise ValueError("Object passed cannot be updated as it doesn't in the system")

	userID = cache.get(feedback.user)
	if userID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	eventID = cache.get(feedback.event)
	if eventID is None:
		raise ValueError("Object depends on an object that is not stored in the system")

	with mysql() as cursor:
		cursor.execute("""UPDATE feedback
		                  SET user = %s, event = %s, rating = %s
		                  WHERE id = %s""", (userID, eventID, feedback.rating, feedbackID))

@locks(Feedback)
def deleteFeedback(feedback):
	feedbackID = cache.get(feedback)
	if feedbackID is None:
		raise ValueError("Object passed cannot be deleted as it doesn't in the system")

	with mysql() as cursor:
		cursor.execute("""DELETE feedback
		                 FROM feedback
		                 WHERE feedback.id=%s""", (feedbackID))
