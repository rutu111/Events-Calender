import unittest

from objects.User import User # any system object that can be stored will do.

from storage import cache

class TestCache(unittest.TestCase):
	user = User("user", None, 1)
	user2 = User("user 2", None, 2)
	def setUp(self):
		pass

	def tearDown(self):
		cache._CACHE = {} # reset cache forcibly

	# since the two are inter-dependant, there's no good way to test them separately.
	def test_get_and_put(self):
		self.assertIsNone(cache.get(1))

		cache.put(1, self.user)
		self.assertEqual(cache.get(1), self.user)
		self.assertEqual(cache.get(self.user), 1)

		# test a second user to make sure that there's no cheating involved.
		cache.put(2, self.user2)
		self.assertEqual(cache.get(2), self.user2)
		self.assertEqual(cache.get(self.user2), 2)

		# check that our second user hasn't interfered with ouot first.
		self.assertEqual(cache.get(1), self.user)
		self.assertEqual(cache.get(self.user), 1)

	def test_associate(self):
		# if get and put don't work, this probably wont either.
		self.test_get_and_put()
		cache._CACHE = {} # reset cache forcibly without flush in case flush fails to work.

		cache.put(1, self.user)
		cache.put(2, self.user2)

		assocKeys = cache.associateKeys([1, 2, None])
		self.assertIsInstance(assocKeys, dict)
		self.assertEqual(assocKeys[1], self.user)
		self.assertEqual(assocKeys[2], self.user2)
		self.assertEqual(len(assocKeys), 2) # check that None got ignored


		assocVals = cache.associateValues([self.user, self.user2, None])
		self.assertIsInstance(assocVals, dict)
		self.assertEqual(assocVals[1], self.user)
		self.assertEqual(assocVals[2], self.user2)
		self.assertEqual(len(assocVals), 2) # check that None got ignored
