from objects.User import User

from storage import cache

from . import mysql, locks

@locks(User)
def setInterests(user, categories):
	userID = cache.get(user)
	if userID is None:
		raise ValueError("Interests cannot be set as user doesn't exist in the system")

	with mysql() as cursor:
		cursor.execute("""DELETE
		                  FROM interests
		                  WHERE user = %s""", (str(userID)))
		for (category, value) in categories.items():
			cursor.execute("""INSERT INTO interests(user, category, rating)
			                  VALUES(%s, %s, %s)""", (str(userID), category, value))



@locks(User)
def getUser(userID):
	if userID is None:
		return None
	cachedUser = cache.get(userID)
	if cachedUser:
		return cachedUser if isinstance(cachedUser, User) else None

	with mysql() as cursor:
		cursor.execute("""SELECT id, username, integration, integration_id, token
		                  FROM users
		                  WHERE id = %s""", (str(userID)))

		result = cursor.fetchone()
		if result is None:
			return None
		user = User(result["username"], result["integration"], result["integration_id"], result["token"])

		cache.put(result["id"], user)

		cursor.execute("""SELECT category, rating
						  FROM interests
						  WHERE user = %s""", (result["id"]))


		user.categories = {r["category"]: r["rating"] for r in cursor.fetchall()}
		return user

@locks(User)
def getUserByIntegration(integration, integration_id):
	with mysql() as cursor:
		cursor.execute("""SELECT id, username, integration, integration_id, token
		                  FROM users
		                  WHERE integration = %s AND integration_id = %s""", (integration, integration_id))

		result = cursor.fetchone()
		if result is None:
			return None

		cachedUser = cache.get(result["id"])
		if cachedUser:
			return cachedUser if isinstance(cachedUser, User) else None

		user = User(result["username"], result["integration"], result["integration_id"], token=result["token"])

		cache.put(result["id"], user)

		return user

@locks(User)
def getAllUsers():
	with mysql() as cursor:
		cursor.execute("""SELECT id, username, integration, integration_id, token
		                  FROM users""")

		allUsers = []
		for result in cursor.fetchall():
			cachedUser = cache.get(result["id"])
			if cachedUser:
				allUsers.append(cachedUser)
				continue

			user = User(result["username"], result["integration"], result["integration_id"], token=result["token"])

			cache.put(result["id"], user)

			allUsers.append(user)
		return allUsers

@locks(User)
def storeUser(user):
	if cache.get(user) is not None:
		raise ValueError("Object passed cannot be stored as it already exists in the system")

	with mysql() as cursor:
		cursor.execute("""INSERT INTO users(username, integration, integration_id, token)
		                 VALUES(%s, %s, %s, %s)""", (user.name, user.integration, user.integrationId, user.token))
		cursor.execute("""SELECT @last_uuid as id""")
		userID = cursor.fetchone()["id"]
		cache.put(userID, user)

@locks(User)
def updateUser(user):
	userID = cache.get(user)
	if userID is None:
		raise ValueError("Object passed cannot be updated as it doesn't in the system")

	with mysql() as cursor:
		cursor.execute("""UPDATE users
		                 SET username = %s, integration = %s, integration_id = %s, token = %s
		                 WHERE id = %s""", (user.name, user.integration, user.integrationId, user.token, userID))
