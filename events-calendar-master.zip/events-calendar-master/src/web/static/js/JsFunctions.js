$(document).ready(function(){
-    $(".button1, .thumbs_up, .thumbs_down, .interest_button, .interest_button2, .rec_going").click(function(){
-		if($(this).hasClass('clicked')) {
-			$(this).removeClass('clicked');
-		} else {
-			$(this).addClass('clicked');
-		}
-    });
-});

$(document).ready(function(){
	$(".form_button_del").click(function(){
      $(".delete_options, .delete_options p, .delete_options h4").css("display", "block");
	  $(".delete_options input, .delete_options span").css("display", "inline-block");
	  $(".form_event > *:not(.delete_options), .form_button").css("display", "none");
	});
});

$(document).ready(function(){
	$(".back").click(function (){
      $(".delete_options, .delete_options *").css("display", "none");
	  $(".form_button").css("display", "block");
	  $(".form_event > *:not(.delete_options)").css("display", "");
	});
});

$(document).ready(function () {
    $('.form').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url : $(this).attr('action'),
            method: $(this).attr('method'),
            data: $(this).serialize(),
            error: function (jXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});

function getMonths(n) {
	//Creating array of months
	var monthName = new Array("January", "February", "March", "April", "May", "June",
		"July", "August", "September", "October", "November", "December");
	var months = new Array();
	var months_last = new Array();
	//Get the current date
	var today = new Date();
	//Get the full year value
	var year = today.getFullYear();
	//get the previous month value  with respect to current month
	var month = today.getMonth()-1;
	if (month == 0) {
		month = 11;
		year--;
	}
	var i = 0;
	//Pushing the last 3 months to array
	while (i < n) {
		months_last.push(monthName[month] + " " + year);
		if (month == 0) {
			month = 11;
			year--;
		} else {
			month--;
		}
		i++;
	}
	months = months_last.reverse();
	var year = today.getFullYear();
	//get and push 9 months in advance including current one
	var month = today.getMonth();
	for (var i = 0; i < 9; i++) {
		months.push(monthName[month] + " " + year);
		if (month == 11) {
			month = 0;
			year++;
		} else {
			month++;
		}
	}
	//returning months array
	return months;
}

function AssignMonthOptions() {
	//Retrieving previous 3 months, current months and 8 next months values
	var optionValues = getMonths(3);
	var dropDown = document.getElementById('months');
	var dropDown2 = document.getElementById('months_resp');
	var today = new Date();
	//Looping through the values and assinging the values to dropdown list
	for (var i = 0; i < optionValues.length; i++) {
		var key = optionValues[i].slice(4, 6);
		var value = optionValues[i];
		dropDown.options[i] = new Option(value, key);
		dropDown2.options[i] = new Option(value, key);
	}
}
//Calling the function on page load
// $(document).ready(AssignMonthOptions)