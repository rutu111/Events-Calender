var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1;} 
  if (n < 1) {slideIndex = slides.length;}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace("active_rec", "");
  }
	slides[slideIndex-1].style.display = "block"; 
	dots[slideIndex-1].className += "active_rec";
}
/*
$(function four() {
  if ($( window ).width() > 1000) {
	alert("four");
	$(".include, .include *").css("display", "inline-block");
  }
});


$(function three() {
  if ($( window ).width() > 700 && $( window ).width() <= 1000) {
	alert("three");
	$(".include, .include *").css("display", "inline-block");
  }
});

$(function two() {
if ($( window ).width() > 450 && $( window ).width() <= 700) {
	alert("two");
	$(".include, .include *").css("display", "inline-block");
}
});

$(function one() {
if ($( window ).width() <= 450) {
	alert("one");
	$(".include, .include *").css("display", "inline-block");
}
});*/