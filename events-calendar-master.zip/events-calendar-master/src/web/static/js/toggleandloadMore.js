$(function(){
	$(".wrapper_all").slice(0, 6).show().css('display','inline-block');
	$("#circle_button").click(function(e){
		e.preventDefault();
		$(".wrapper_all:hidden").slice(0, 6).show().css('display','inline-block');
		if ($(".wrapper_all").last().css("display") != "none"){
		$(".scroll_align_all").css("display", "none");
	}
	});
});

$(function(){
	$(".wrapper_pop").slice(0, 6).show().css('display','inline-block');
	$("#circle_btn").click(function(e){
		e.preventDefault();
		$(".wrapper_pop:hidden").slice(0, 6).show().css('display','inline-block');
		if ($(".wrapper_pop").last().css("display") != "none"){
		$(".scroll_align").css("display", "none");
	}
	});

});
$(document).ready(function(){
	if ($(".wrapper_pop").last().css("display") != "none"){
		$(".scroll_align").css("display", "none");
	}
	if ($(".wrapper_all").last().css("display") != "none"){
		$(".scroll_align_all").css("display", "none");
	}
});
$(document).ready(function(){
    $(".more").click(function(){
      if($(this).parent().hasClass('open_div')) {
        $(this).parent().animate({maxHeight: "310px"}).removeClass('open_div');
      } else { 
        $(this).parent().animate({maxHeight: "500px"}).addClass('open_div');
      }
    });
});