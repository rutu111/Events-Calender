import random
from django.test import SimpleTestCase, Client

from web import views

from logic.events import getEvents, getPopularEvents

# http://blog.appliedinformaticsinc.com/test-client-as-testing-tool-for-get-and-post-requests-in-django/
class TestUrls(SimpleTestCase):
	"""Test to make sure that these pages returns an HTTP 200 status code - standard response for a successful HTTP request"""

	@classmethod
	def setUpClass(self):
		# creating instance of a client.
		self.client = Client()

	def setUp(self):
		views.DEBUG_LOGIN = False

	def test_homepage_load(self):
		homepage = self.client.get("/")
		self.assertEqual(homepage.status_code, 200)
		html = homepage.content.decode('utf8')  # extract content of the homepage
		self.assertTrue("<title>Events Calendar</title>" in html)

	def test_login_load(self):
		response = self.client.get('/login')  # path('', views.login)
		self.assertEqual(response.status_code, 302)  # redirect to integration

	def test_logout_load(self):
		response = self.client.get('/logout')  # path('', views.logout)
		self.assertEqual(response.status_code, 302) # redirect to homepage

	def test_feedback_load(self):
		views.DEBUG_LOGIN = True # pretend we're logged in
		response = self.client.get('/feedback')  # path('', views.feedback)
		self.assertEqual(response.status_code, 400)  # Bad request

	def test_adminlogin_load(self):
		response = self.client.get('/adminlogin') # path('', views.adminlogin)
		self.assertEqual(response.status_code, 200)

	def test_admin_load(self):
		response = self.client.get('/admin') # path('', views.admin)
		self.assertEqual(response.status_code, 401) # Unathorised

	# TODO maybe test if events show up correctly on homepage - see test_event_show()
	def test_event_show(self):
		homepage = self.client.get("/")
		html = homepage.content.decode('utf8')  # extract content of the homepage
		hasPopularEvents = False
		for event in getPopularEvents():
			if event.title in html:
				hasPopularEvents = True
			break
		self.assertTrue(hasPopularEvents)


	 # TODO test that, given certain input, different results are given
	def test_login_input(self):
		response = self.client.post('/login', {'code': 'fakecode', 'state': 'fakestate'})
		self.assertEqual(response.status_code, 401) # authorization failed | test authorization failed


	# TODO check that user has been logged out
	def test_logout(self):
		response = self.client.get('/logout')
		user = views._getCurrentUser(self.client)
		self.assertIsNone(user)
		self.assertEqual(response.status_code, 302)

	# TODO test that, given certain input, different results are given
	def test_feedback(self):
		# geta list of events
		events_list = getEvents()

		# select random events from that list
		event1 = random.choice(events_list)
		event2 = random.choice(events_list)
		event3 = random.choice(events_list)

		# valid/invalid rating and event combination
		response1 = self.client.post('/feedback', {'rating': 0, 'event': event1})
		self.assertEqual(response1.status_code, 200) # successful response as rating is within the scope
		response2 = self.client.post('/feedback', {'rating': 1, 'event': event2})
		self.assertEqual(response2.status_code, 200)
		response3 = self.client.post('/feedback', {'rating': -1, 'event': event3})
		self.assertEqual(response3.status_code, 400)

		# set event3 to None
		event3 = None

		response4 = self.client.post('/feedback', {'rating': 1, 'event': event3})
		self.assertEqual(response4.status_code, 400)
