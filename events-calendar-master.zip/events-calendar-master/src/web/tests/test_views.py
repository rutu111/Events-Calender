from django.test import SimpleTestCase
from django.urls import resolve
from web.views import main

class TestViews(SimpleTestCase):
	"""Test if root url resolves to a homepage view"""
	def test_root_page_resolves_to_homepage_view(self):
		found = resolve('/')
		self.assertEqual(found.func, main)
