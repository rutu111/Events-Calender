from datetime import datetime
from dateutil.relativedelta import relativedelta

from django.shortcuts import render, redirect
from django.http import HttpResponse

from logic.events import getEvent, getEventRuns, getPopularEvents, filterEvents, getCategories, createEvent as l_createEvent, editEvent as l_editEvent, validateEvent, deleteEvent as l_deleteEvent, updateEvent
from logic.recommendations import getRecommendedEvents, getPositiveEvents, getNegativeEvents, getPositiveFeedbackCount, getNegativeFeedbackCount, generateRecommendations
from logic.users import getUser, getLoginURL, authenticate, doFeedback, adminLogin, setInterests
from logic.integrations import integrations

try:
	from settings_base import DEBUG_LOGIN
except ImportError:
	DEBUG_LOGIN = False

def _getCurrentUser(request):
	if DEBUG_LOGIN:
		from objects.User import User
		from logic.users import getAllUsers
		try:
			return getAllUsers()[0]
		except IndexError:
			return User("Example User", None, 1)
	if "login_id" in request.session:
		return getUser(*request.session["login_id"])
	return None

def _gatherFilters(params, prefix):
	return {key[len(prefix):-2 if key.endswith("[]") else None]: value if key.endswith("[]") else value[0] for (key, value) in params.lists() if key.startswith(prefix)}

def main(req): # the homepage
	curUser = _getCurrentUser(req)
	filters = _gatherFilters(req.GET, "filter_")
	filters["user"] = curUser
	if "month" not in filters:
		filters["month"] = datetime.now().strftime("%B %Y")
	try:
		currentMonth = datetime.strptime(filters["month"], "%B %Y")
	except ValueError:
		currentMonth = datetime.now()

	events = filterEvents(getEventRuns(), filters)
	popularEvents = filterEvents(getPopularEvents(), filters)
	recommendations = getRecommendedEvents(curUser) if curUser else []
	allEvents = set(events + popularEvents + recommendations)
	# set some conveniece variables
	for e in allEvents:
		e.likes = getPositiveFeedbackCount(e)
		e.dislikes = getNegativeFeedbackCount(e)

	template = render(req, 'main.djt', { # render the template "main.djt" with the following variables set:
		"events": events,
		"categories": getCategories(),
		"popularEvents": popularEvents,
		"recommendations": recommendations,
		"user": curUser,
		"positiveFeedbackEvents": getPositiveEvents(curUser),
		"negativeFeedbackEvents": getNegativeEvents(curUser),
		"thisMonth": currentMonth,
		"lastMonth": currentMonth + relativedelta(months=-1),
		"nextMonth": currentMonth + relativedelta(months=+1),
		"monthDeltas": [currentMonth + relativedelta(months=x) for x in range(-3, 9)],
		"filters": filters
	})
	# to keep the objects clean
	for e in allEvents:
		del e.likes
		del e.dislikes

	return template

def adminlogin(req): # the admin login page
	loginURL = getLoginURL()

	if "username" in req.POST and "password" in req.POST:
		if adminLogin(req.POST["username"], req.POST["password"]):
			req.session["admin"] = True
			return redirect("/admin")

	req.session["login_state"] = loginURL.state
	return render(req, 'adminlogin.djt', { # render the template "adminlogin.djt" with the following variables set:
		"loginURL": loginURL.url
	})

def admin(req): # the admin page
	if "admin" not in req.session or not req.session["admin"]:
		return HttpResponse("You must login as an admin to view this page", status=401)

	if "id[]" in req.POST:
		postArrays = {key[0:-2]: value for key, value in req.POST.lists() if key[-2:] == "[]"}
		values = zip(*postArrays.values())
		for dataRaw in values:
			data = {key: value for key, value in zip(dict(postArrays).keys(), dataRaw)}
			event = getEvent(data["id"])
			if event:
				if "delete" in data:
					l_deleteEvent(event)
				else:
					newEvent = validateEvent(data)
					if newEvent:
						l_editEvent(event, newEvent)
					else:
						print("Invalid modification")
			else:
				print("Invalid id: %s" % data["id"])


	loginURL = getLoginURL()
	req.session["login_state"] = loginURL.state
	curUser = _getCurrentUser(req)
	filters = _gatherFilters(req.GET, "filter_")
	filters["user"] = curUser
	return render(req, 'admin.djt', { # render the template "admin.djt" with the following variables set:
		"events": filterEvents(getEventRuns(), filters),
		"categories": getCategories(),
		"user": curUser
	})

def logout(req):
	if "login_id" in req.session:
		del req.session["login_id"]
	return redirect("/")

def login(req):
	# no need to login if we're already logged in
	if _getCurrentUser(req) is not None:
		return redirect("/")

	if "code" in req.GET:
		params = req.GET
	elif "code" in req.POST:
		params = req.POST
	else: # if no code was sent, redirect to loginURL (assume no login attempt)
		if "with" in req.GET:
			integration = req.GET["with"]
			if integration not in integrations:
				return HttpResponse("Cannot login with invlid integration", status=400)
			loginURL = getLoginURL(integration)
		else:
			loginURL = getLoginURL()
		req.session["login_state"] = loginURL.state
		return redirect(loginURL.url)

	try:
		if "state" not in params: # check the state exists
			raise TypeError("No state value provided")
		if req.session.get("login_state") is None or params["state"] != req.session["login_state"]: # is set and matches what we expect
			raise TypeError("Invalid state value provided")

		user = authenticate(params["code"]) # try logging in.
		req.session["login_id"] = (user.integration, user.integrationId)
		return redirect("/") # redirect to the homepage
	except TypeError as e:
		return HttpResponse(e, status=401)

def feedback(req):
	user = _getCurrentUser(req)
	if user is None:
		return HttpResponse("Not logged in", status=401)
	if "event" in req.POST and "rating" in req.POST:
		event = getEvent(req.POST["event"])
		if event is not None:
			doFeedback(user, event, req.POST["rating"])
		else:
			return HttpResponse("invalid event provided", status=400)
	else:
		return HttpResponse("No event or rating provided", status=400)
	return redirect("/")

def createEvent(req):
	user = _getCurrentUser(req)
	if user is None:
		return HttpResponse("anonymous users cannot create events", status=401)

	try:
		event = validateEvent(req.POST)
		event.owner = user
	except ValueError as e:
		return HttpResponse(e, status=400)

	l_createEvent(event)

	return redirect("/")

def editEvent(req):
	user = _getCurrentUser(req)
	if user is None:
		return HttpResponse("anonymous users cannot modify events", status=401)

	try:
		event = validateEvent(req.POST)
	except ValueError as e:
		return HttpResponse(e, status=400)


	oldEvent = getEvent(req.POST["event"])
	if oldEvent is None:
		return HttpResponse("invalid event id to edit", status=400)

	if user is not oldEvent.owner:
		return HttpResponse("you cannot modify an event you do not own", status=403)
	l_editEvent(oldEvent, event)

	return redirect("/")

def deleteEvent(req):
	user = _getCurrentUser(req)
	if user is None:
		return HttpResponse("anonymous users cannot delete events", status=401)


	event = getEvent(req.POST["event"])
	if event is None:
		return HttpResponse("invalid event id to delete", status=400)

	if user is not event.owner:
		return HttpResponse("you cannot delete an event you do not own", status=403)

	l_deleteEvent(event)
	return redirect("/")

def cancelEvent(req):
	user = _getCurrentUser(req)
	if user is None:
		return HttpResponse("anonymous users cannot cancel events", status=401)

	event = getEvent(req.POST["event"])
	if event is None:
		return HttpResponse("invalid event id to cancel", status=400)

	if user is not event.owner:
		return HttpResponse("you cannot cancel an event you do not own", status=403)

	event.cancelled = True
	updateEvent(event)
	return redirect("/")

def interests(req):

	user = _getCurrentUser(req)
	if user is None:
		return HttpResponse("Not logged in", status=401)

	if "categories" not in req.POST:
		return HttpResponse("Missing categories", status=400)

	categories = req.POST.getlist("categories")
	categoryWeights = {category:1 for category in categories if category}
	negativeCategoryWeights = {category:0.1 for  category in getCategories() if category not in categories}
	categoryWeights = {**categoryWeights, **negativeCategoryWeights}
	print(categoryWeights)

	setInterests(user, categoryWeights)

	return redirect("/")

def gen(req):
	if "admin" not in req.session or not req.session["admin"]:
		return HttpResponse("You must be an admin to do this", status=401)

	generateRecommendations(override=True)
	return redirect("/admin")

