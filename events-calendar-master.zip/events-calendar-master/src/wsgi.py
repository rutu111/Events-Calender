"""
WSGI config

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/2.0/howto/deployment/wsgi/
"""

import os
import sys

from django.core.wsgi import get_wsgi_application

try:
	import settings_base
except ImportError as exc:
	raise ImportError(
		"Couldn't import settings. Are you sure that you copied the "
		"example-settings file? Don't forget to change the default "
		"values."
	) from exc

sys.path += [settings_base.BASE_DIR]

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings_base")

application = get_wsgi_application()
